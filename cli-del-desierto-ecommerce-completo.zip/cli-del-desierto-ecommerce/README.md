# 🌿 Clí+ Del Desierto - E-commerce

E-commerce especializado en sistemas de climatización y refrigeración, desarrollado con React + TypeScript + Vite.

## 🏢 Acerca de la Empresa

**Clí+ Del Desierto** es una empresa especializada en:
- Aires acondicionados (Minisplit, ventana, centrales, industriales)
- Enfriadores y evaporativos portátiles e industriales
- Ventiladores de techo, pedestal e industriales
- Refrigeración doméstica y comercial
- Gases refrigerantes (R410A, R22, R134A)
- Refacciones y accesorios

📞 **Contacto**: (871) 524 4276  
📍 **Ubicación**: Torreón, México

## 🚀 Características del E-commerce

### ✅ Funcionalidades Principales
- **Sistema de usuarios** completo con autenticación
- **Catálogo de productos** con 25+ productos especializados
- **Búsqueda avanzada** con filtros múltiples
- **Sistema de cotización B2B** para ventas especializadas
- **Carrito de compras** con checkout de 3 pasos
- **Múltiples métodos de pago** (Tarjeta, OXXO, Transferencia)
- **Panel de administración** con gestión completa
- **Diseño responsive** móvil-primera

### 🎨 Diseño
- Estilo **MercadoLibre** familiar y confiable
- Branding corporativo con colores azul y verde
- Logo con dinosaurio integrado
- 100% responsive en todos los dispositivos

### 🏷️ Marcas Principales
- **Frikko** - Evaporativos de uso rudo
- **Mirage** - Aires acondicionados
- **Symphony** - Enfriadores portátiles
- **Carrier** - Equipos industriales

## 🛠️ Tecnologías Utilizadas

- **Frontend**: React 18 + TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS + shadcn/ui
- **Routing**: React Router DOM
- **State Management**: Context API + useReducer
- **Icons**: Lucide React
- **Forms**: React Hook Form + Zod validation

## 📦 Instalación

1. **Clona el repositorio**:
```bash
git clone https://github.com/tu-usuario/cli-del-desierto-ecommerce.git
cd cli-del-desierto-ecommerce
```

2. **Instala las dependencias**:
```bash
npm install
# o
pnpm install
# o
yarn install
```

3. **Ejecuta el servidor de desarrollo**:
```bash
npm run dev
# o
pnpm dev
# o
yarn dev
```

4. **Abre tu navegador** en `http://localhost:5173`

## 🔧 Scripts Disponibles

```bash
npm run dev          # Servidor de desarrollo
npm run build        # Build de producción
npm run preview      # Vista previa del build
npm run lint         # Ejecutar ESLint
```

## 👥 Credenciales de Prueba

### Administrador
- **Email**: admin@climasdeldesierto.com
- **Password**: admin123

### Cliente
- **Email**: juan.perez@email.com
- **Password**: password123

## 📁 Estructura del Proyecto

```
src/
├── components/          # Componentes reutilizables
│   ├── common/         # Componentes generales
│   ├── layout/         # Layout components (Header, Footer)
│   ├── product/        # Componentes de productos
│   └── ui/             # Componentes UI base
├── pages/              # Páginas principales
├── context/            # Context API para estado global
├── hooks/              # Custom hooks
├── types/              # Tipos TypeScript
├── lib/                # Utilidades y configuración
└── data/               # Datos mock (JSON)
```

## 🎯 Funcionalidades por Página

### 🏠 Homepage
- Hero section con llamada a la acción
- Categorías destacadas
- Productos populares
- Información de contacto

### 🛍️ Catálogo de Productos
- Grid de productos responsive
- Filtros por categoría, marca, precio
- Búsqueda en tiempo real
- Ordenamiento múltiple

### 📄 Detalle de Producto
- Galería de imágenes
- Especificaciones técnicas completas
- Agregar al carrito/cotizador
- Productos relacionados

### 🛒 Carrito de Compras
- Gestión de cantidades
- Cálculo automático de totales
- Validación de stock
- Proceso de checkout

### 💰 Sistema de Cotización
- Cotizador B2B personalizado
- Formulario de solicitud
- Seguimiento de estado
- Historial de cotizaciones

### 👤 Perfil de Usuario
- Información personal
- Historial de compras
- Lista de favoritos
- Gestión de cotizaciones

## 🔐 Autenticación

El sistema incluye:
- Registro de nuevos usuarios
- Inicio de sesión seguro
- Gestión de sesiones
- Roles de usuario (cliente/admin)
- Rutas protegidas

## 📱 Responsive Design

- **Mobile**: Diseño optimizado para móviles
- **Tablet**: Layout adaptado para tablets
- **Desktop**: Experiencia completa de escritorio
- **Navegación móvil**: Menú hamburguesa y controles táctiles

## 🚀 Deployment

Para hacer deployment:

```bash
npm run build
```

Los archivos optimizados estarán en la carpeta `dist/`.

## 📈 Próximas Características

- [ ] Integración con API de pagos real
- [ ] Sistema de reseñas de productos
- [ ] Chat en vivo para soporte
- [ ] Notificaciones push
- [ ] Sistema de cupones y descuentos
- [ ] Integración con ERP/CRM

## 🤝 Contribuir

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para detalles.

## 📞 Soporte

Para soporte técnico o preguntas:
- **Email**: soporte@climasdeldesierto.com
- **Teléfono**: (871) 524 4276
- **Issues**: [GitHub Issues](https://github.com/tu-usuario/cli-del-desierto-ecommerce/issues)

---

**Desarrollado con ❤️ para Clí+ Del Desierto**
