import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { AppState, AuthState, CartState, User, CartItem } from '../types';

// Tipos para las acciones
type AuthAction = 
  | { type: 'LOGIN'; payload: User }
  | { type: 'LOGOUT' }
  | { type: 'SET_LOADING'; payload: boolean };

type CartAction = 
  | { type: 'ADD_ITEM'; payload: CartItem }
  | { type: 'REMOVE_ITEM'; payload: string }
  | { type: 'UPDATE_QUANTITY'; payload: { productId: string; quantity: number } }
  | { type: 'CLEAR_CART' }
  | { type: 'LOAD_CART'; payload: CartItem[] };

type WishlistAction = 
  | { type: 'ADD_TO_WISHLIST'; payload: string }
  | { type: 'REMOVE_FROM_WISHLIST'; payload: string }
  | { type: 'LOAD_WISHLIST'; payload: string[] };

type AppAction = AuthAction | CartAction | WishlistAction;

// Estado inicial
const initialAuthState: AuthState = {
  user: null,
  isAuthenticated: false,
  loading: false,
};

const initialCartState: CartState = {
  items: [],
  total: 0,
  itemCount: 0,
};

const initialState: AppState = {
  auth: initialAuthState,
  cart: initialCartState,
  wishlist: [],
  currentUser: null,
};

// Reducers
const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case 'LOGIN':
      return {
        ...state,
        user: action.payload,
        isAuthenticated: true,
        loading: false,
      };
    case 'LOGOUT':
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        loading: false,
      };
    case 'SET_LOADING':
      return {
        ...state,
        loading: action.payload,
      };
    default:
      return state;
  }
};

const cartReducer = (state: CartState, action: CartAction): CartState => {
  switch (action.type) {
    case 'ADD_ITEM': {
      const existingItemIndex = state.items.findIndex(
        item => item.productId === action.payload.productId
      );
      
      let newItems;
      if (existingItemIndex >= 0) {
        newItems = state.items.map((item, index) =>
          index === existingItemIndex
            ? { ...item, quantity: item.quantity + action.payload.quantity }
            : item
        );
      } else {
        newItems = [...state.items, action.payload];
      }
      
      const newTotal = newItems.reduce((total, item) => total + (item.price * item.quantity), 0);
      const newItemCount = newItems.reduce((count, item) => count + item.quantity, 0);
      
      return {
        items: newItems,
        total: newTotal,
        itemCount: newItemCount,
      };
    }
    case 'REMOVE_ITEM': {
      const newItems = state.items.filter(item => item.productId !== action.payload);
      const newTotal = newItems.reduce((total, item) => total + (item.price * item.quantity), 0);
      const newItemCount = newItems.reduce((count, item) => count + item.quantity, 0);
      
      return {
        items: newItems,
        total: newTotal,
        itemCount: newItemCount,
      };
    }
    case 'UPDATE_QUANTITY': {
      const newItems = state.items.map(item =>
        item.productId === action.payload.productId
          ? { ...item, quantity: action.payload.quantity }
          : item
      ).filter(item => item.quantity > 0);
      
      const newTotal = newItems.reduce((total, item) => total + (item.price * item.quantity), 0);
      const newItemCount = newItems.reduce((count, item) => count + item.quantity, 0);
      
      return {
        items: newItems,
        total: newTotal,
        itemCount: newItemCount,
      };
    }
    case 'CLEAR_CART':
      return {
        items: [],
        total: 0,
        itemCount: 0,
      };
    case 'LOAD_CART': {
      const newTotal = action.payload.reduce((total, item) => total + (item.price * item.quantity), 0);
      const newItemCount = action.payload.reduce((count, item) => count + item.quantity, 0);
      
      return {
        items: action.payload,
        total: newTotal,
        itemCount: newItemCount,
      };
    }
    default:
      return state;
  }
};

const wishlistReducer = (state: string[], action: WishlistAction): string[] => {
  switch (action.type) {
    case 'ADD_TO_WISHLIST':
      return state.includes(action.payload) ? state : [...state, action.payload];
    case 'REMOVE_FROM_WISHLIST':
      return state.filter(id => id !== action.payload);
    case 'LOAD_WISHLIST':
      return action.payload;
    default:
      return state;
  }
};

// Reducer principal
const appReducer = (state: AppState, action: AppAction): AppState => {
  return {
    auth: authReducer(state.auth, action as AuthAction),
    cart: cartReducer(state.cart, action as CartAction),
    wishlist: wishlistReducer(state.wishlist, action as WishlistAction),
    currentUser: state.auth.user,
  };
};

// Contexto
const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  addToCart: (productId: string, quantity: number, price: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  addToWishlist: (productId: string) => void;
  removeFromWishlist: (productId: string) => void;
} | undefined>(undefined);

// Hook personalizado para usar el contexto
export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

// Provider component
export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Cargar datos del localStorage al inicializar
  useEffect(() => {
    const savedAuth = localStorage.getItem('cli-auth');
    const savedCart = localStorage.getItem('cli-cart');
    const savedWishlist = localStorage.getItem('cli-wishlist');

    if (savedAuth) {
      try {
        const auth = JSON.parse(savedAuth);
        if (auth.user) {
          dispatch({ type: 'LOGIN', payload: auth.user });
        }
      } catch (error) {
        console.error('Error loading auth data:', error);
      }
    }

    if (savedCart) {
      try {
        const cart = JSON.parse(savedCart);
        dispatch({ type: 'LOAD_CART', payload: cart });
      } catch (error) {
        console.error('Error loading cart data:', error);
      }
    }

    if (savedWishlist) {
      try {
        const wishlist = JSON.parse(savedWishlist);
        dispatch({ type: 'LOAD_WISHLIST', payload: wishlist });
      } catch (error) {
        console.error('Error loading wishlist data:', error);
      }
    }
  }, []);

  // Guardar en localStorage cuando cambie el estado
  useEffect(() => {
    localStorage.setItem('cli-auth', JSON.stringify(state.auth));
  }, [state.auth]);

  useEffect(() => {
    localStorage.setItem('cli-cart', JSON.stringify(state.cart.items));
  }, [state.cart.items]);

  useEffect(() => {
    localStorage.setItem('cli-wishlist', JSON.stringify(state.wishlist));
  }, [state.wishlist]);

  // Funciones de utilidad
  const login = async (email: string, password: string): Promise<boolean> => {
    dispatch({ type: 'SET_LOADING', payload: true });
    
    try {
      // Simular llamada a API
      const response = await fetch('/data/users.json');
      const users = await response.json();
      
      const user = users.find((u: User) => u.email === email && u.password === password);
      
      if (user) {
        dispatch({ type: 'LOGIN', payload: user });
        return true;
      } else {
        dispatch({ type: 'SET_LOADING', payload: false });
        return false;
      }
    } catch (error) {
      dispatch({ type: 'SET_LOADING', payload: false });
      console.error('Login error:', error);
      return false;
    }
  };

  const logout = () => {
    dispatch({ type: 'LOGOUT' });
    localStorage.removeItem('cli-auth');
  };

  const addToCart = (productId: string, quantity: number, price: number) => {
    dispatch({
      type: 'ADD_ITEM',
      payload: { productId, quantity, price }
    });
  };

  const removeFromCart = (productId: string) => {
    dispatch({ type: 'REMOVE_ITEM', payload: productId });
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    dispatch({ type: 'UPDATE_QUANTITY', payload: { productId, quantity } });
  };

  const clearCart = () => {
    dispatch({ type: 'CLEAR_CART' });
  };

  const addToWishlist = (productId: string) => {
    dispatch({ type: 'ADD_TO_WISHLIST', payload: productId });
  };

  const removeFromWishlist = (productId: string) => {
    dispatch({ type: 'REMOVE_FROM_WISHLIST', payload: productId });
  };

  const value = {
    state,
    dispatch,
    login,
    logout,
    addToCart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    addToWishlist,
    removeFromWishlist,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};
