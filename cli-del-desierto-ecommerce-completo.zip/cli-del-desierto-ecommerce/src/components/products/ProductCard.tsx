import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, ShoppingCart, Star, Package, Zap } from 'lucide-react';
import { Product, Brand, Category } from '../../types';
import { useApp } from '../../context/AppContext';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';

interface ProductCardProps {
  product: Product;
  brand?: Brand;
  category?: Category;
  className?: string;
}

const ProductCard: React.FC<ProductCardProps> = ({ 
  product, 
  brand, 
  category, 
  className = "" 
}) => {
  const { state, addToCart, addToWishlist, removeFromWishlist } = useApp();
  
  const isInWishlist = state.wishlist.includes(product.id);
  const isInStock = product.stock > 0;
  
  const discountPercentage = product.comparePrice > product.price 
    ? Math.round(((product.comparePrice - product.price) / product.comparePrice) * 100)
    : 0;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isInStock) {
      addToCart(product.id, 1, product.price);
    }
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isInWishlist) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product.id);
    }
  };

  return (
    <div className={`group relative bg-white rounded-lg border border-gray-200 hover:border-blue-300 hover:shadow-lg transition-all duration-300 overflow-hidden ${className}`}>
      <Link to={`/producto/${product.id}`}>
        {/* Image container */}
        <div className="relative aspect-square overflow-hidden bg-gray-50">
          {product.images && product.images.length > 0 ? (
            <img
              src={product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iI2Y4ZjlmYSIvPgogIDxwYXRoIGQ9Ik0xMDAgNzBjLTE2LjU2OSAwLTMwIDEzLjQzMS0zMCAzMHMxMy40MzEgMzAgMzAgMzAgMzAtMTMuNDMxIDMwLTMwLTEzLjQzMS0zMC0zMC0zMHptMCA0NWMtOC4yODQgMC0xNS02Ljc1My0xNS0xNSAwLTguMjg0IDYuNzE2LTE1IDE1LTE1czE1IDYuNzE2IDE1IDE1Yy4wMzggOC4yNDctNi43NTMgMTUtMTUgMTV6bTAtMjVjLTUuNTIzIDAtMTAgNC40NzctMTAgMTBzNC40NzcgMTAgMTAgMTAgMTAtNC40NzcgMTAtMTAtNC40NzctMTAtMTAtMTB6Ii8+Cjwvc3ZnPgo=';
              }}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gray-100">
              <Package className="h-12 w-12 text-gray-400" />
            </div>
          )}

          {/* Badges */}
          <div className="absolute top-2 left-2 flex flex-col space-y-1">
            {product.isFeatured && (
              <Badge className="bg-yellow-500 hover:bg-yellow-600 text-white">
                <Star className="h-3 w-3 mr-1" />
                Destacado
              </Badge>
            )}
            {discountPercentage > 0 && (
              <Badge className="bg-red-500 hover:bg-red-600 text-white">
                -{discountPercentage}%
              </Badge>
            )}
            {!isInStock && (
              <Badge variant="secondary" className="bg-gray-500 text-white">
                Agotado
              </Badge>
            )}
          </div>

          {/* Wishlist button */}
          <button
            onClick={handleWishlistToggle}
            className={`absolute top-2 right-2 p-2 rounded-full transition-all duration-200 ${
              isInWishlist 
                ? 'bg-red-500 text-white shadow-lg' 
                : 'bg-white/80 hover:bg-white text-gray-600 hover:text-red-500'
            }`}
          >
            <Heart className={`h-4 w-4 ${isInWishlist ? 'fill-current' : ''}`} />
          </button>

          {/* Quick add to cart button */}
          {isInStock && (
            <button
              onClick={handleAddToCart}
              className="absolute bottom-2 right-2 p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-full opacity-0 group-hover:opacity-100 transition-all duration-200 transform translate-y-2 group-hover:translate-y-0"
            >
              <ShoppingCart className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Product info */}
        <div className="p-4">
          {/* Brand and category */}
          <div className="flex items-center justify-between mb-2">
            {brand && (
              <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded">
                {brand.name}
              </span>
            )}
            {category && (
              <span className="text-xs text-gray-500">
                {category.name}
              </span>
            )}
          </div>

          {/* Product name */}
          <h3 className="font-medium text-gray-900 mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors">
            {product.name}
          </h3>

          {/* Key specs */}
          {product.specifications && (
            <div className="mb-3 space-y-1">
              {product.specifications.btus && (
                <div className="flex items-center text-xs text-gray-600">
                  <Zap className="h-3 w-3 mr-1 text-yellow-500" />
                  <span>{product.specifications.btus}</span>
                </div>
              )}
              {product.specifications.voltage && (
                <div className="text-xs text-gray-500">
                  Voltaje: {product.specifications.voltage}
                </div>
              )}
            </div>
          )}

          {/* Price */}
          <div className="space-y-1">
            {product.comparePrice > product.price && (
              <span className="text-sm text-gray-400 line-through">
                ${product.comparePrice.toLocaleString('es-MX')}
              </span>
            )}
            <div className="flex items-baseline space-x-2">
              <span className="text-xl font-bold text-gray-900">
                ${product.price.toLocaleString('es-MX')}
              </span>
              {discountPercentage > 0 && (
                <span className="text-sm font-medium text-green-600">
                  Ahorra ${(product.comparePrice - product.price).toLocaleString('es-MX')}
                </span>
              )}
            </div>
          </div>

          {/* Stock info */}
          <div className="mt-2 flex items-center justify-between">
            <div className="text-xs text-gray-500">
              {isInStock ? (
                <>
                  <span className="text-green-600 font-medium">Disponible</span>
                  {product.stock <= 5 && (
                    <span className="text-orange-600 ml-1">
                      (Últimas {product.stock} unidades)
                    </span>
                  )}
                </>
              ) : (
                <span className="text-red-600 font-medium">Sin stock</span>
              )}
            </div>
          </div>

          {/* Tags */}
          {product.tags && product.tags.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-1">
              {product.tags.slice(0, 2).map((tag) => (
                <span
                  key={tag}
                  className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded"
                >
                  {tag}
                </span>
              ))}
            </div>
          )}
        </div>
      </Link>
    </div>
  );
};

export default ProductCard;
