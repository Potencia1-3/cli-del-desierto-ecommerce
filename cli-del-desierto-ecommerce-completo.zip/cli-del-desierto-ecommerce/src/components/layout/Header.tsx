import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, ShoppingCart, User, Heart, Menu, X, Phone, MessageCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useCompany } from '../../hooks/useCompany';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';

const Header: React.FC = () => {
  const { state, logout } = useApp();
  const { company } = useCompany();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/productos?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      {/* Top bar - Contact info */}
      <div className="bg-gradient-to-r from-blue-600 to-green-600 text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center space-x-4">
            <span className="flex items-center space-x-1">
              <Phone className="h-4 w-4" />
              <span>{company?.phone || '(871) 524 4276'}</span>
            </span>
            <span className="hidden md:block">|</span>
            <span className="hidden md:block">La mejor refrigeración para la Laguna</span>
          </div>
          <div className="flex items-center space-x-4">
            <a
              href={company?.socialMedia?.whatsapp || `https://wa.me/528715244276`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-1 hover:text-yellow-300 transition-colors"
            >
              <MessageCircle className="h-4 w-4" />
              <span className="hidden sm:inline">WhatsApp</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-green-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">C+</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">
                <span className="text-blue-600">Clí+</span>{' '}
                <span className="text-gray-700">Del Desierto</span>
              </h1>
              <p className="text-xs text-gray-500 hidden sm:block">Climatización profesional</p>
            </div>
          </Link>

          {/* Search bar */}
          <div className="flex-1 max-w-2xl mx-8 hidden md:block">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="Buscar aires acondicionados, enfriadores, ventiladores..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-4 pr-12 py-3 w-full border-2 border-gray-200 focus:border-blue-500 rounded-full"
              />
              <Button
                type="submit"
                size="sm"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-blue-600 hover:bg-blue-700 rounded-full px-4"
              >
                <Search className="h-4 w-4" />
              </Button>
            </form>
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-4">
            {/* Wishlist */}
            <Link to="/favoritos" className="hidden md:flex items-center space-x-1 text-gray-600 hover:text-blue-600 transition-colors">
              <Heart className="h-5 w-5" />
              <span className="text-sm">Favoritos</span>
              {state.wishlist.length > 0 && (
                <span className="bg-red-500 text-white text-xs rounded-full px-2 py-1 ml-1">
                  {state.wishlist.length}
                </span>
              )}
            </Link>

            {/* Cart */}
            <Link to="/carrito" className="flex items-center space-x-1 text-gray-600 hover:text-blue-600 transition-colors">
              <div className="relative">
                <ShoppingCart className="h-6 w-6" />
                {state.cart.itemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full px-2 py-1 min-w-[20px] text-center">
                    {state.cart.itemCount}
                  </span>
                )}
              </div>
              <div className="hidden md:block">
                <span className="text-sm block">Carrito</span>
                {state.cart.total > 0 && (
                  <span className="text-xs text-gray-500">
                    ${state.cart.total.toLocaleString('es-MX')}
                  </span>
                )}
              </div>
            </Link>

            {/* User menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-1">
                  <User className="h-5 w-5" />
                  <span className="hidden md:inline">
                    {state.auth.isAuthenticated ? state.auth.user?.firstName : 'Cuenta'}
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                {state.auth.isAuthenticated ? (
                  <>
                    <DropdownMenuItem asChild>
                      <Link to="/perfil">Mi Perfil</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link to="/pedidos">Mis Pedidos</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link to="/cotizaciones">Mis Cotizaciones</Link>
                    </DropdownMenuItem>
                    {state.auth.user?.role === 'admin' && (
                      <>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link to="/admin">Panel Admin</Link>
                        </DropdownMenuItem>
                      </>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      Cerrar Sesión
                    </DropdownMenuItem>
                  </>
                ) : (
                  <>
                    <DropdownMenuItem asChild>
                      <Link to="/login">Iniciar Sesión</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link to="/registro">Crear Cuenta</Link>
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Mobile menu toggle */}
            <Button
              variant="ghost"
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile search */}
        <div className="md:hidden mt-4">
          <form onSubmit={handleSearch} className="relative">
            <Input
              type="text"
              placeholder="Buscar productos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-4 pr-12 py-3 w-full border-2 border-gray-200 focus:border-blue-500 rounded-full"
            />
            <Button
              type="submit"
              size="sm"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-blue-600 hover:bg-blue-700 rounded-full px-4"
            >
              <Search className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="container mx-auto px-4 py-4 space-y-4">
            <Link 
              to="/favoritos" 
              className="flex items-center space-x-2 text-gray-600 hover:text-blue-600"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <Heart className="h-5 w-5" />
              <span>Favoritos ({state.wishlist.length})</span>
            </Link>
            
            {state.auth.isAuthenticated ? (
              <>
                <Link 
                  to="/perfil" 
                  className="block text-gray-600 hover:text-blue-600"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Mi Perfil
                </Link>
                <Link 
                  to="/pedidos" 
                  className="block text-gray-600 hover:text-blue-600"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Mis Pedidos
                </Link>
                <Link 
                  to="/cotizaciones" 
                  className="block text-gray-600 hover:text-blue-600"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Mis Cotizaciones
                </Link>
                {state.auth.user?.role === 'admin' && (
                  <Link 
                    to="/admin" 
                    className="block text-gray-600 hover:text-blue-600"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    Panel Admin
                  </Link>
                )}
                <button 
                  onClick={() => {
                    handleLogout();
                    setIsMobileMenuOpen(false);
                  }}
                  className="block text-gray-600 hover:text-blue-600 w-full text-left"
                >
                  Cerrar Sesión
                </button>
              </>
            ) : (
              <>
                <Link 
                  to="/login" 
                  className="block text-gray-600 hover:text-blue-600"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Iniciar Sesión
                </Link>
                <Link 
                  to="/registro" 
                  className="block text-gray-600 hover:text-blue-600"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Crear Cuenta
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
