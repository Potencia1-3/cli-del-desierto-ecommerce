import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, Wind, Snowflake, Fan, Refrigerator, Wrench, Package } from 'lucide-react';
import { useProducts } from '../../hooks/useProducts';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';
import { Button } from '../ui/button';

const CategoryNav: React.FC = () => {
  const { categories, loading } = useProducts();

  if (loading) {
    return (
      <nav className="bg-gray-50 border-b">
        <div className="container mx-auto px-4 py-3">
          <div className="flex space-x-6 animate-pulse">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-6 bg-gray-200 rounded w-24"></div>
            ))}
          </div>
        </div>
      </nav>
    );
  }

  const getCategoryIcon = (categoryId: string) => {
    switch (categoryId) {
      case 'aires-acondicionados':
        return <Snowflake className="h-4 w-4" />;
      case 'enfriadores-evaporativos':
        return <Wind className="h-4 w-4" />;
      case 'ventiladores':
        return <Fan className="h-4 w-4" />;
      case 'refrigeracion':
        return <Refrigerator className="h-4 w-4" />;
      case 'gases-refrigerantes':
        return <Package className="h-4 w-4" />;
      case 'refacciones':
        return <Wrench className="h-4 w-4" />;
      default:
        return <Package className="h-4 w-4" />;
    }
  };

  const mainCategories = categories.filter(cat => cat.parentId === null);
  
  const getSubcategories = (parentId: string) => {
    return categories.filter(cat => cat.parentId === parentId);
  };

  return (
    <nav className="bg-gray-50 border-b shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center space-x-1 overflow-x-auto py-3">
          {/* Categorías dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center space-x-1 text-gray-700 hover:text-blue-600 hover:bg-blue-50 px-3 py-2 rounded-lg">
                <Package className="h-4 w-4" />
                <span className="font-medium">Categorías</span>
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-80 max-h-96 overflow-y-auto">
              {mainCategories.map((category) => {
                const subcategories = getSubcategories(category.id);
                return (
                  <div key={category.id}>
                    <DropdownMenuItem asChild>
                      <Link 
                        to={`/categoria/${category.id}`}
                        className="flex items-center space-x-3 px-3 py-2 hover:bg-blue-50 w-full"
                      >
                        {getCategoryIcon(category.id)}
                        <div>
                          <span className="font-medium text-gray-900">{category.name}</span>
                          <p className="text-xs text-gray-500 mt-1">{category.description}</p>
                        </div>
                      </Link>
                    </DropdownMenuItem>
                    {subcategories.length > 0 && (
                      <>
                        <div className="px-6 py-1">
                          <div className="grid grid-cols-2 gap-1">
                            {subcategories.map((subcat) => (
                              <DropdownMenuItem asChild key={subcat.id}>
                                <Link 
                                  to={`/categoria/${subcat.id}`}
                                  className="text-sm text-gray-600 hover:text-blue-600 hover:bg-blue-50 px-2 py-1 rounded"
                                >
                                  {subcat.name}
                                </Link>
                              </DropdownMenuItem>
                            ))}
                          </div>
                        </div>
                        <DropdownMenuSeparator />
                      </>
                    )}
                  </div>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Enlaces principales de categorías */}
          <div className="hidden md:flex items-center space-x-1">
            {mainCategories.slice(0, 5).map((category) => (
              <Link
                key={category.id}
                to={`/categoria/${category.id}`}
                className="flex items-center space-x-1 text-gray-700 hover:text-blue-600 hover:bg-blue-50 px-3 py-2 rounded-lg transition-colors whitespace-nowrap"
              >
                {getCategoryIcon(category.id)}
                <span className="text-sm font-medium">{category.name}</span>
              </Link>
            ))}
          </div>

          {/* Enlaces adicionales */}
          <div className="hidden lg:flex items-center space-x-1 ml-auto">
            <Link
              to="/ofertas"
              className="text-sm font-medium text-red-600 hover:text-red-700 hover:bg-red-50 px-3 py-2 rounded-lg transition-colors"
            >
              🔥 Ofertas
            </Link>
            <Link
              to="/instalacion"
              className="text-sm font-medium text-green-600 hover:text-green-700 hover:bg-green-50 px-3 py-2 rounded-lg transition-colors"
            >
              🔧 Instalación
            </Link>
            <Link
              to="/servicios"
              className="text-sm font-medium text-blue-600 hover:text-blue-700 hover:bg-blue-50 px-3 py-2 rounded-lg transition-colors"
            >
              🛠️ Servicios
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default CategoryNav;
