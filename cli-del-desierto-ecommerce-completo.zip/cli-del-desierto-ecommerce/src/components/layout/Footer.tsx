import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Clock, MessageCircle, Facebook, Instagram } from 'lucide-react';
import { useCompany } from '../../hooks/useCompany';

const Footer: React.FC = () => {
  const { company } = useCompany();

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main footer content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-green-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">C+</span>
              </div>
              <div>
                <h3 className="text-xl font-bold">
                  <span className="text-blue-400">Clí+</span> Del Desierto
                </h3>
                <p className="text-sm text-gray-400">Climatización profesional</p>
              </div>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              {company?.description || "Aires acondicionados, enfriadores, minisplit y más. Frescura para cada estilo de vida."}
            </p>
            <div className="flex space-x-4">
              <a
                href={company?.socialMedia?.facebook || "#"}
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-blue-400 transition-colors"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href={`https://instagram.com/${company?.socialMedia?.instagram?.replace('@', '') || 'clideldesiert'}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-pink-400 transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href={company?.socialMedia?.whatsapp || "https://wa.me/528715244276"}
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-green-400 transition-colors"
              >
                <MessageCircle className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-white">Contacto</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <Phone className="h-5 w-5 text-blue-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">{company?.phone || "(871) 524 4276"}</p>
                  <p className="text-sm text-gray-400">Lunes a Viernes 9AM - 6PM</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <MessageCircle className="h-5 w-5 text-green-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">WhatsApp</p>
                  <p className="text-sm text-gray-400">Atención inmediata</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Mail className="h-5 w-5 text-purple-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">{company?.email || "ventas@clideldesiert.com"}</p>
                  <p className="text-sm text-gray-400">Cotizaciones y ventas</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-red-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">
                    {company?.address?.street || "Av. Las Arboledas III"}
                  </p>
                  <p className="text-sm text-gray-400">
                    {`${company?.address?.city || "Torreón"}, ${company?.address?.state || "Coahuila"}`}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-white">Enlaces Rápidos</h4>
            <div className="space-y-2">
              <Link to="/productos" className="block text-gray-300 hover:text-white transition-colors">
                Todos los Productos
              </Link>
              <Link to="/categoria/aires-acondicionados" className="block text-gray-300 hover:text-white transition-colors">
                Aires Acondicionados
              </Link>
              <Link to="/categoria/enfriadores-evaporativos" className="block text-gray-300 hover:text-white transition-colors">
                Enfriadores Evaporativos
              </Link>
              <Link to="/categoria/ventiladores" className="block text-gray-300 hover:text-white transition-colors">
                Ventiladores
              </Link>
              <Link to="/categoria/refrigeracion" className="block text-gray-300 hover:text-white transition-colors">
                Refrigeración
              </Link>
              <Link to="/cotizaciones" className="block text-gray-300 hover:text-white transition-colors">
                Solicitar Cotización
              </Link>
            </div>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-white">Servicios</h4>
            <div className="space-y-2">
              <Link to="/instalacion" className="block text-gray-300 hover:text-white transition-colors">
                Instalación Profesional
              </Link>
              <Link to="/mantenimiento" className="block text-gray-300 hover:text-white transition-colors">
                Mantenimiento
              </Link>
              <Link to="/reparacion" className="block text-gray-300 hover:text-white transition-colors">
                Reparación
              </Link>
              <Link to="/garantia" className="block text-gray-300 hover:text-white transition-colors">
                Garantía
              </Link>
              <Link to="/financiamiento" className="block text-gray-300 hover:text-white transition-colors">
                Financiamiento
              </Link>
              <Link to="/ayuda" className="block text-gray-300 hover:text-white transition-colors">
                Centro de Ayuda
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Business Hours */}
      <div className="border-t border-gray-800">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-center space-x-2 text-gray-300">
            <Clock className="h-5 w-5 text-yellow-400" />
            <span className="font-medium">Horarios de Atención:</span>
            <span>Lun-Vie 9:00 AM - 6:00 PM | Sáb 9:00 AM - 2:00 PM</span>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-800 bg-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-2 md:space-y-0">
            <div className="text-sm text-gray-400">
              © 2024 Clí+ Del Desierto. Todos los derechos reservados.
            </div>
            <div className="flex space-x-6 text-sm">
              <Link to="/privacidad" className="text-gray-400 hover:text-white transition-colors">
                Política de Privacidad
              </Link>
              <Link to="/terminos" className="text-gray-400 hover:text-white transition-colors">
                Términos y Condiciones
              </Link>
              <Link to="/cookies" className="text-gray-400 hover:text-white transition-colors">
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
