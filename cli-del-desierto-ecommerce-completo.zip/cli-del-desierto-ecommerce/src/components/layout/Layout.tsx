import React from 'react';
import Header from './Header';
import CategoryNav from './CategoryNav';
import Footer from './Footer';

interface LayoutProps {
  children: React.ReactNode;
  showCategoryNav?: boolean;
}

const Layout: React.FC<LayoutProps> = ({ children, showCategoryNav = true }) => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      {showCategoryNav && <CategoryNav />}
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
};

export default Layout;
