import { useState, useEffect } from 'react';
import { Product, Category, Brand, SearchFilters } from '../types';

export const useProducts = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        const [productsRes, categoriesRes, brandsRes] = await Promise.all([
          fetch('/data/products.json'),
          fetch('/data/categories.json'),
          fetch('/data/brands.json')
        ]);

        if (!productsRes.ok || !categoriesRes.ok || !brandsRes.ok) {
          throw new Error('Error fetching data');
        }

        const [productsData, categoriesData, brandsData] = await Promise.all([
          productsRes.json(),
          categoriesRes.json(),
          brandsRes.json()
        ]);

        setProducts(productsData);
        setCategories(categoriesData);
        setBrands(brandsData);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error loading data');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return { products, categories, brands, loading, error };
};

export const useProductsFiltered = (filters: SearchFilters) => {
  const { products, categories, brands, loading, error } = useProducts();
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);

  useEffect(() => {
    if (!products.length) return;

    let filtered = [...products];

    // Filtrar por activos
    filtered = filtered.filter(product => product.isActive);

    // Filtrar por búsqueda de texto
    if (filters.query) {
      const query = filters.query.toLowerCase();
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(query) ||
        product.description.toLowerCase().includes(query) ||
        product.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }

    // Filtrar por categoría
    if (filters.category) {
      filtered = filtered.filter(product => product.categoryId === filters.category);
    }

    // Filtrar por marca
    if (filters.brand) {
      filtered = filtered.filter(product => product.brandId === filters.brand);
    }

    // Filtrar por precio
    if (filters.minPrice !== undefined) {
      filtered = filtered.filter(product => product.price >= filters.minPrice!);
    }

    if (filters.maxPrice !== undefined) {
      filtered = filtered.filter(product => product.price <= filters.maxPrice!);
    }

    // Filtrar por stock
    if (filters.inStock) {
      filtered = filtered.filter(product => product.stock > 0);
    }

    // Filtrar productos destacados
    if (filters.featured) {
      filtered = filtered.filter(product => product.isFeatured);
    }

    setFilteredProducts(filtered);
  }, [products, filters]);

  return { 
    products: filteredProducts, 
    categories, 
    brands, 
    loading, 
    error 
  };
};

export const useProduct = (productId: string) => {
  const { products, categories, brands, loading, error } = useProducts();
  const [product, setProduct] = useState<Product | null>(null);
  const [category, setCategory] = useState<Category | null>(null);
  const [brand, setBrand] = useState<Brand | null>(null);

  useEffect(() => {
    if (!products.length || !productId) return;

    const foundProduct = products.find(p => p.id === productId);
    setProduct(foundProduct || null);

    if (foundProduct) {
      const foundCategory = categories.find(c => c.id === foundProduct.categoryId);
      const foundBrand = brands.find(b => b.id === foundProduct.brandId);
      setCategory(foundCategory || null);
      setBrand(foundBrand || null);
    }
  }, [products, categories, brands, productId]);

  return { product, category, brand, loading, error };
};

export const useFeaturedProducts = (limit: number = 8) => {
  const { products, loading, error } = useProducts();
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);

  useEffect(() => {
    if (!products.length) return;

    const featured = products
      .filter(product => product.isFeatured && product.isActive)
      .slice(0, limit);

    setFeaturedProducts(featured);
  }, [products, limit]);

  return { featuredProducts, loading, error };
};

export const useProductsByCategory = (categoryId: string, limit?: number) => {
  const { products, categories, loading, error } = useProducts();
  const [categoryProducts, setCategoryProducts] = useState<Product[]>([]);

  useEffect(() => {
    if (!products.length || !categoryId || !categories.length) return;

    // Find the category and its subcategories
    const category = categories.find(cat => cat.id === categoryId);
    const subcategories = categories.filter(cat => cat.parentId === categoryId);
    
    // Create list of category IDs to include
    const categoryIds = [categoryId];
    if (subcategories.length > 0) {
      // If it's a parent category, include all subcategory IDs
      categoryIds.push(...subcategories.map(sub => sub.id));
    }

    let filtered = products.filter(product => 
      categoryIds.includes(product.categoryId) && product.isActive
    );

    if (limit) {
      filtered = filtered.slice(0, limit);
    }

    setCategoryProducts(filtered);
  }, [products, categories, categoryId, limit]);

  return { categoryProducts, loading, error };
};

export const useRelatedProducts = (productId: string, limit: number = 4) => {
  const { product } = useProduct(productId);
  const { products, loading, error } = useProducts();
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);

  useEffect(() => {
    if (!product || !products.length) return;

    const related = products
      .filter(p => 
        p.id !== productId && 
        p.isActive && 
        (p.categoryId === product.categoryId || p.brandId === product.brandId)
      )
      .slice(0, limit);

    setRelatedProducts(related);
  }, [product, products, productId, limit]);

  return { relatedProducts, loading, error };
};
