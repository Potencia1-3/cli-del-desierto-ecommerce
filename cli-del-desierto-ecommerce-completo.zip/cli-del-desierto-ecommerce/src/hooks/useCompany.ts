import { useState, useEffect } from 'react';
import { Company } from '../types';

export const useCompany = () => {
  const [company, setCompany] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCompany = async () => {
      try {
        setLoading(true);
        const response = await fetch('/data/company.json');
        
        if (!response.ok) {
          throw new Error('Error fetching company data');
        }

        const companyData = await response.json();
        setCompany(companyData);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error loading company data');
      } finally {
        setLoading(false);
      }
    };

    fetchCompany();
  }, []);

  return { company, loading, error };
};
