import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Plus, 
  Calculator, 
  Clock, 
  CheckCircle, 
  X, 
  Eye, 
  Package, 
  Calendar,
  Filter,
  FileText,
  Download,
  MessageCircle,
  Phone
} from 'lucide-react';
import Layout from '../components/layout/Layout';
import { useApp } from '../context/AppContext';
import { useProducts } from '../hooks/useProducts';
import { useCompany } from '../hooks/useCompany';
import { Quote, Product } from '../types';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../components/ui/dialog';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';

const QuotesPage: React.FC = () => {
  const { state } = useApp();
  const { products, brands } = useProducts();
  const { company } = useCompany();
  
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewQuoteDialog, setShowNewQuoteDialog] = useState(false);
  const [selectedQuote, setSelectedQuote] = useState<Quote | null>(null);
  const [filter, setFilter] = useState('all');

  // New quote form state
  const [newQuote, setNewQuote] = useState({
    selectedProducts: [] as { productId: string; quantity: number }[],
    notes: '',
    selectedProductId: '',
    quantity: 1
  });

  // Load quotes
  useEffect(() => {
    const loadQuotes = async () => {
      try {
        const response = await fetch('/data/quotes.json');
        const quotesData = await response.json();
        
        // Filter quotes for current user
        const userQuotes = quotesData.filter((quote: Quote) => 
          quote.userId === state.auth.user?.id
        );
        
        setQuotes(userQuotes);
      } catch (error) {
        console.error('Error loading quotes:', error);
      } finally {
        setLoading(false);
      }
    };

    if (state.auth.user) {
      loadQuotes();
    }
  }, [state.auth.user]);

  const getStatusColor = (status: Quote['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'quoted':
        return 'bg-blue-100 text-blue-800';
      case 'accepted':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: Quote['status']) => {
    switch (status) {
      case 'pending':
        return 'Pendiente';
      case 'quoted':
        return 'Cotizada';
      case 'accepted':
        return 'Aceptada';
      case 'rejected':
        return 'Rechazada';
      default:
        return status;
    }
  };

  const filteredQuotes = quotes.filter(quote => {
    if (filter === 'all') return true;
    return quote.status === filter;
  });

  const handleAddProductToQuote = () => {
    if (newQuote.selectedProductId && newQuote.quantity > 0) {
      const existingIndex = newQuote.selectedProducts.findIndex(
        p => p.productId === newQuote.selectedProductId
      );

      if (existingIndex >= 0) {
        const updated = [...newQuote.selectedProducts];
        updated[existingIndex].quantity += newQuote.quantity;
        setNewQuote(prev => ({ ...prev, selectedProducts: updated }));
      } else {
        setNewQuote(prev => ({
          ...prev,
          selectedProducts: [
            ...prev.selectedProducts,
            { productId: newQuote.selectedProductId, quantity: newQuote.quantity }
          ]
        }));
      }

      setNewQuote(prev => ({ ...prev, selectedProductId: '', quantity: 1 }));
    }
  };

  const handleRemoveProductFromQuote = (productId: string) => {
    setNewQuote(prev => ({
      ...prev,
      selectedProducts: prev.selectedProducts.filter(p => p.productId !== productId)
    }));
  };

  const handleSubmitQuote = async () => {
    if (newQuote.selectedProducts.length === 0) return;

    try {
      // Simulate API call
      const newQuoteData: Quote = {
        id: `quote-${Date.now()}`,
        userId: state.auth.user!.id,
        items: newQuote.selectedProducts.map(item => {
          const product = products.find(p => p.id === item.productId);
          return {
            productId: item.productId,
            quantity: item.quantity,
            requestedPrice: product?.price || 0,
            quotedPrice: null
          };
        }),
        status: 'pending',
        notes: newQuote.notes,
        adminNotes: '',
        total: newQuote.selectedProducts.reduce((sum, item) => {
          const product = products.find(p => p.id === item.productId);
          return sum + (product?.price || 0) * item.quantity;
        }, 0),
        createdAt: new Date().toISOString(),
        quotedAt: null,
        expiresAt: null
      };

      setQuotes(prev => [newQuoteData, ...prev]);
      setShowNewQuoteDialog(false);
      setNewQuote({
        selectedProducts: [],
        notes: '',
        selectedProductId: '',
        quantity: 1
      });
    } catch (error) {
      console.error('Error submitting quote:', error);
    }
  };

  const QuoteCard: React.FC<{ quote: Quote }> = ({ quote }) => {
    const quoteProducts = quote.items.map(item => {
      const product = products.find(p => p.id === item.productId);
      return { ...item, product };
    });

    return (
      <Card className="hover:shadow-lg transition-shadow">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg">Cotización #{quote.id}</CardTitle>
              <p className="text-sm text-gray-500">
                Creada el {new Date(quote.createdAt).toLocaleDateString('es-MX')}
              </p>
            </div>
            <Badge className={getStatusColor(quote.status)}>
              {getStatusText(quote.status)}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Products summary */}
            <div>
              <p className="text-sm font-medium mb-2">
                {quote.items.length} producto{quote.items.length !== 1 ? 's' : ''}
              </p>
              <div className="space-y-2">
                {quoteProducts.slice(0, 2).map((item, index) => (
                  <div key={index} className="flex items-center space-x-2 text-sm">
                    <Package className="h-4 w-4 text-gray-400" />
                    <span className="flex-1 truncate">
                      {item.product?.name || 'Producto no encontrado'}
                    </span>
                    <span className="text-gray-500">x{item.quantity}</span>
                  </div>
                ))}
                {quote.items.length > 2 && (
                  <p className="text-sm text-gray-500">
                    y {quote.items.length - 2} más...
                  </p>
                )}
              </div>
            </div>

            {/* Total */}
            <div className="flex justify-between items-center border-t pt-4">
              <span className="font-medium">
                {quote.status === 'quoted' && quote.quotedTotal 
                  ? 'Total Cotizado:' 
                  : 'Total Solicitado:'
                }
              </span>
              <span className="text-lg font-semibold">
                ${(quote.quotedTotal || quote.total).toLocaleString('es-MX')}
              </span>
            </div>

            {/* Actions */}
            <div className="flex space-x-2 pt-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSelectedQuote(quote)}
                className="flex-1"
              >
                <Eye className="h-4 w-4 mr-2" />
                Ver Detalles
              </Button>
              
              {quote.status === 'quoted' && (
                <Button size="sm" className="flex-1">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Aceptar
                </Button>
              )}
            </div>

            {/* Expiry warning */}
            {quote.status === 'quoted' && quote.expiresAt && (
              <div className="text-sm text-orange-600 bg-orange-50 p-2 rounded">
                <Calendar className="h-4 w-4 inline mr-1" />
                Expira el {new Date(quote.expiresAt).toLocaleDateString('es-MX')}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const QuoteDetailsDialog: React.FC = () => {
    if (!selectedQuote) return null;

    const quoteProducts = selectedQuote.items.map(item => {
      const product = products.find(p => p.id === item.productId);
      const brand = product ? brands.find(b => b.id === product.brandId) : null;
      return { ...item, product, brand };
    });

    return (
      <Dialog open={!!selectedQuote} onOpenChange={() => setSelectedQuote(null)}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <span>Cotización #{selectedQuote.id}</span>
              <Badge className={getStatusColor(selectedQuote.status)}>
                {getStatusText(selectedQuote.status)}
              </Badge>
            </DialogTitle>
            <DialogDescription>
              Creada el {new Date(selectedQuote.createdAt).toLocaleDateString('es-MX')} a las{' '}
              {new Date(selectedQuote.createdAt).toLocaleTimeString('es-MX')}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Products */}
            <div>
              <h3 className="font-semibold mb-4">Productos Solicitados</h3>
              <div className="space-y-4">
                {quoteProducts.map((item, index) => (
                  <div key={index} className="flex items-start space-x-4 p-4 border rounded-lg">
                    <div className="w-16 h-16 bg-gray-100 rounded flex-shrink-0">
                      {item.product?.images?.[0] ? (
                        <img
                          src={item.product.images[0]}
                          alt={item.product.name}
                          className="w-full h-full object-cover rounded"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Package className="h-6 w-6 text-gray-400" />
                        </div>
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          {item.brand && (
                            <Badge variant="secondary" className="mb-1">
                              {item.brand.name}
                            </Badge>
                          )}
                          <h4 className="font-medium">
                            {item.product?.name || 'Producto no encontrado'}
                          </h4>
                          <p className="text-sm text-gray-500">
                            Cantidad: {item.quantity}
                          </p>
                        </div>
                        
                        <div className="text-right">
                          <div className="text-sm text-gray-500">Precio solicitado</div>
                          <div className="font-medium">
                            ${item.requestedPrice.toLocaleString('es-MX')}
                          </div>
                          {item.quotedPrice && (
                            <>
                              <div className="text-sm text-green-600 mt-1">Precio cotizado</div>
                              <div className="font-semibold text-green-600">
                                ${item.quotedPrice.toLocaleString('es-MX')}
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Notes */}
            {selectedQuote.notes && (
              <div>
                <h3 className="font-semibold mb-2">Notas del Cliente</h3>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-sm">{selectedQuote.notes}</p>
                </div>
              </div>
            )}

            {/* Admin response */}
            {selectedQuote.adminNotes && (
              <div>
                <h3 className="font-semibold mb-2">Respuesta de Clí+ Del Desierto</h3>
                <div className="bg-blue-50 p-3 rounded-lg">
                  <p className="text-sm">{selectedQuote.adminNotes}</p>
                </div>
              </div>
            )}

            {/* Totals */}
            <div className="border-t pt-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Total Solicitado:</span>
                  <span>${selectedQuote.total.toLocaleString('es-MX')}</span>
                </div>
                {selectedQuote.quotedTotal && (
                  <div className="flex justify-between font-semibold text-lg">
                    <span>Total Cotizado:</span>
                    <span className="text-green-600">
                      ${selectedQuote.quotedTotal.toLocaleString('es-MX')}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="flex space-x-3 pt-4 border-t">
              {selectedQuote.status === 'quoted' && (
                <>
                  <Button className="flex-1 bg-green-600 hover:bg-green-700">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Aceptar Cotización
                  </Button>
                  <Button variant="outline" className="flex-1">
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Contactar por WhatsApp
                  </Button>
                </>
              )}
              
              {selectedQuote.status === 'pending' && (
                <Button variant="outline" className="flex-1">
                  <Phone className="h-4 w-4 mr-2" />
                  Llamar para seguimiento
                </Button>
              )}
              
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Descargar PDF
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  if (loading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
            {[1, 2, 3].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Mis Cotizaciones</h1>
            <p className="text-gray-600 mt-1">
              Gestiona y da seguimiento a tus solicitudes de cotización
            </p>
          </div>
          
          <Dialog open={showNewQuoteDialog} onOpenChange={setShowNewQuoteDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nueva Cotización
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Solicitar Nueva Cotización</DialogTitle>
                <DialogDescription>
                  Agrega los productos que necesitas cotizar y enviaremos tu solicitud
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Product selector */}
                <div className="space-y-4">
                  <Label>Agregar Productos</Label>
                  <div className="flex space-x-2">
                    <Select
                      value={newQuote.selectedProductId}
                      onValueChange={(value) => setNewQuote(prev => ({ ...prev, selectedProductId: value }))}
                    >
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Seleccionar producto" />
                      </SelectTrigger>
                      <SelectContent>
                        {products.map((product) => (
                          <SelectItem key={product.id} value={product.id}>
                            {product.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    <Input
                      type="number"
                      min="1"
                      value={newQuote.quantity}
                      onChange={(e) => setNewQuote(prev => ({ ...prev, quantity: parseInt(e.target.value) || 1 }))}
                      className="w-20"
                      placeholder="Cant."
                    />
                    
                    <Button onClick={handleAddProductToQuote} disabled={!newQuote.selectedProductId}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* Selected products */}
                {newQuote.selectedProducts.length > 0 && (
                  <div>
                    <Label>Productos Seleccionados</Label>
                    <div className="space-y-2 mt-2">
                      {newQuote.selectedProducts.map((item, index) => {
                        const product = products.find(p => p.id === item.productId);
                        return (
                          <div key={index} className="flex items-center justify-between p-3 border rounded">
                            <div>
                              <span className="font-medium">{product?.name}</span>
                              <span className="text-gray-500 ml-2">x{item.quantity}</span>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRemoveProductFromQuote(item.productId)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Notes */}
                <div>
                  <Label htmlFor="notes">Notas Adicionales</Label>
                  <Textarea
                    id="notes"
                    placeholder="Describe cualquier requerimiento especial, instalación, descuentos por volumen, etc."
                    value={newQuote.notes}
                    onChange={(e) => setNewQuote(prev => ({ ...prev, notes: e.target.value }))}
                    className="mt-1"
                  />
                </div>

                {/* Actions */}
                <div className="flex space-x-3">
                  <Button
                    onClick={handleSubmitQuote}
                    disabled={newQuote.selectedProducts.length === 0}
                    className="flex-1"
                  >
                    <Calculator className="h-4 w-4 mr-2" />
                    Enviar Cotización
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowNewQuoteDialog(false)}
                  >
                    Cancelar
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters */}
        <div className="flex space-x-2 mb-6">
          <Button
            variant={filter === 'all' ? 'default' : 'outline'}
            onClick={() => setFilter('all')}
            size="sm"
          >
            Todas ({quotes.length})
          </Button>
          <Button
            variant={filter === 'pending' ? 'default' : 'outline'}
            onClick={() => setFilter('pending')}
            size="sm"
          >
            <Clock className="h-4 w-4 mr-1" />
            Pendientes ({quotes.filter(q => q.status === 'pending').length})
          </Button>
          <Button
            variant={filter === 'quoted' ? 'default' : 'outline'}
            onClick={() => setFilter('quoted')}
            size="sm"
          >
            <FileText className="h-4 w-4 mr-1" />
            Cotizadas ({quotes.filter(q => q.status === 'quoted').length})
          </Button>
        </div>

        {/* Quotes list */}
        {filteredQuotes.length === 0 ? (
          <div className="text-center py-12">
            <Calculator className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {filter === 'all' ? 'No tienes cotizaciones' : 'No hay cotizaciones en esta categoría'}
            </h3>
            <p className="text-gray-500 mb-6">
              {filter === 'all' 
                ? 'Solicita tu primera cotización para obtener precios personalizados'
                : 'Cambia el filtro para ver otras cotizaciones'
              }
            </p>
            {filter === 'all' && (
              <Button onClick={() => setShowNewQuoteDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Solicitar Cotización
              </Button>
            )}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredQuotes.map((quote) => (
              <QuoteCard key={quote.id} quote={quote} />
            ))}
          </div>
        )}

        {/* Quote details modal */}
        <QuoteDetailsDialog />

        {/* Contact info */}
        {quotes.length > 0 && (
          <div className="mt-12 bg-blue-50 p-6 rounded-lg">
            <h3 className="font-semibold mb-3">¿Necesitas ayuda con tus cotizaciones?</h3>
            <p className="text-sm text-gray-600 mb-4">
              Nuestro equipo está listo para ayudarte con cualquier duda sobre tus cotizaciones
            </p>
            <div className="flex space-x-3">
              <Button size="sm" variant="outline">
                <Phone className="h-4 w-4 mr-2" />
                {company?.phone}
              </Button>
              <Button size="sm" variant="outline">
                <MessageCircle className="h-4 w-4 mr-2" />
                WhatsApp
              </Button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default QuotesPage;
