import React from 'react';
import { useParams } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import ProductGrid from '../components/products/ProductGrid';
import { useProductsByCategory, useProducts } from '../hooks/useProducts';

const CategoryPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { categoryProducts, loading } = useProductsByCategory(id || '');
  const { categories, brands } = useProducts();
  
  const category = categories.find(cat => cat.id === id);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {category?.name || 'Categoría'}
          </h1>
          <p className="text-gray-600">
            {category?.description || 'Productos de esta categoría'}
          </p>
        </div>

        <ProductGrid
          products={categoryProducts}
          brands={brands}
          categories={categories}
          loading={loading}
          columns={4}
        />
      </div>
    </Layout>
  );
};

export default CategoryPage;
