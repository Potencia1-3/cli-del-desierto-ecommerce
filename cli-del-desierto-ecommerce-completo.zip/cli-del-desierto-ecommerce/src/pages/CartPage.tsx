import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  ArrowRight, 
  Heart,
  Package,
  Truck,
  Shield,
  Calculator
} from 'lucide-react';
import Layout from '../components/layout/Layout';
import { useApp } from '../context/AppContext';
import { useProducts } from '../hooks/useProducts';
import { Product } from '../types';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Alert, AlertDescription } from '../components/ui/alert';

const CartPage: React.FC = () => {
  const { state, removeFromCart, updateCartQuantity, clearCart } = useApp();
  const { products, brands } = useProducts();
  const navigate = useNavigate();
  
  const [cartProducts, setCartProducts] = useState<(Product & { cartQuantity: number })[]>([]);
  const [loading, setLoading] = useState(true);

  // Load cart products with details
  useEffect(() => {
    if (products.length > 0 && state.cart.items.length > 0) {
      const enrichedItems = state.cart.items.map(cartItem => {
        const product = products.find(p => p.id === cartItem.productId);
        return product ? { ...product, cartQuantity: cartItem.quantity } : null;
      }).filter(Boolean) as (Product & { cartQuantity: number })[];
      
      setCartProducts(enrichedItems);
      setLoading(false);
    } else {
      setCartProducts([]);
      setLoading(false);
    }
  }, [products, state.cart.items]);

  const handleQuantityChange = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(productId);
    } else {
      updateCartQuantity(productId, newQuantity);
    }
  };

  const handleRemoveItem = (productId: string) => {
    removeFromCart(productId);
  };

  const handleClearCart = () => {
    if (window.confirm('¿Estás seguro de que quieres vaciar el carrito?')) {
      clearCart();
    }
  };

  const subtotal = state.cart.total;
  const shipping = subtotal > 5000 ? 0 : 500; // Free shipping over $5000
  const tax = subtotal * 0.16; // 16% IVA
  const total = subtotal + shipping + tax;

  const proceedToCheckout = () => {
    if (state.auth.isAuthenticated) {
      navigate('/checkout');
    } else {
      navigate('/login', { 
        state: { 
          from: { pathname: '/checkout' },
          message: 'Inicia sesión para continuar con tu compra'
        }
      });
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
            {[1, 2, 3].map(i => (
              <div key={i} className="flex space-x-4 p-4 border rounded">
                <div className="w-20 h-20 bg-gray-200 rounded"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Layout>
    );
  }

  if (cartProducts.length === 0) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <div className="text-center max-w-md mx-auto">
            <ShoppingBag className="h-24 w-24 text-gray-300 mx-auto mb-6" />
            <h1 className="text-2xl font-bold text-gray-900 mb-4">
              Tu carrito está vacío
            </h1>
            <p className="text-gray-600 mb-8">
              ¡Descubre nuestros productos de climatización y encuentra lo que necesitas!
            </p>
            <Button asChild size="lg">
              <Link to="/productos">
                <Package className="h-5 w-5 mr-2" />
                Explorar Productos
              </Link>
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Carrito de Compras
            </h1>
            <p className="text-gray-600 mt-1">
              {state.cart.itemCount} {state.cart.itemCount === 1 ? 'producto' : 'productos'} en tu carrito
            </p>
          </div>
          <Button variant="outline" onClick={handleClearCart} className="text-red-600 hover:text-red-700">
            <Trash2 className="h-4 w-4 mr-2" />
            Vaciar Carrito
          </Button>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart items */}
          <div className="lg:col-span-2 space-y-4">
            {cartProducts.map((item) => {
              const brand = brands.find(b => b.id === item.brandId);
              const itemTotal = item.price * item.cartQuantity;
              
              return (
                <Card key={item.id}>
                  <CardContent className="p-6">
                    <div className="flex space-x-4">
                      {/* Product image */}
                      <div className="flex-shrink-0">
                        <Link to={`/producto/${item.id}`}>
                          <div className="w-24 h-24 bg-gray-100 rounded-lg overflow-hidden">
                            {item.images && item.images.length > 0 ? (
                              <img
                                src={item.images[0]}
                                alt={item.name}
                                className="w-full h-full object-cover hover:scale-105 transition-transform"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iI2Y4ZjlmYSIvPgogIDxwYXRoIGQ9Ik0xMDAgNzBjLTE2LjU2OSAwLTMwIDEzLjQzMS0zMCAzMHMxMy40MzEgMzAgMzAgMzAgMzAtMTMuNDMxIDMwLTMwLTEzLjQzMS0zMC0zMC0zMHptMCA0NWMtOC4yODQgMC0xNS02Ljc1My0xNS0xNSAwLTguMjg0IDYuNzE2LTE1IDE1LTE1czE1IDYuNzE2IDE1IDE1Yy4wMzggOC4yNDctNi43NTMgMTUtMTUgMTV6bTAtMjVjLTUuNTIzIDAtMTAgNC40NzctMTAgMTBzNC40NzcgMTAgMTAgMTAgMTAtNC40NzcgMTAtMTAtNC40NzctMTAtMTAtMTB6Ii8+Cjwvc3ZnPgo=';
                                }}
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <Package className="h-8 w-8 text-gray-400" />
                              </div>
                            )}
                          </div>
                        </Link>
                      </div>

                      {/* Product details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            {brand && (
                              <Badge variant="secondary" className="mb-1">
                                {brand.name}
                              </Badge>
                            )}
                            <h3 className="font-medium text-gray-900 line-clamp-2">
                              <Link 
                                to={`/producto/${item.id}`}
                                className="hover:text-blue-600 transition-colors"
                              >
                                {item.name}
                              </Link>
                            </h3>
                            <p className="text-sm text-gray-500 mt-1">
                              SKU: {item.sku}
                            </p>
                            {item.specifications?.btus && (
                              <p className="text-sm text-gray-600 mt-1">
                                {item.specifications.btus}
                              </p>
                            )}
                          </div>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveItem(item.id)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50 ml-4"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>

                        {/* Price and quantity controls */}
                        <div className="flex items-center justify-between mt-4">
                          {/* Quantity controls */}
                          <div className="flex items-center space-x-2">
                            <span className="text-sm font-medium">Cantidad:</span>
                            <div className="flex items-center border border-gray-300 rounded-lg">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleQuantityChange(item.id, item.cartQuantity - 1)}
                                className="px-2 py-1 h-8"
                              >
                                <Minus className="h-3 w-3" />
                              </Button>
                              <span className="px-3 py-1 text-center min-w-[40px] text-sm">
                                {item.cartQuantity}
                              </span>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleQuantityChange(item.id, item.cartQuantity + 1)}
                                disabled={item.cartQuantity >= item.stock}
                                className="px-2 py-1 h-8"
                              >
                                <Plus className="h-3 w-3" />
                              </Button>
                            </div>
                            <span className="text-xs text-gray-500">
                              ({item.stock} disponibles)
                            </span>
                          </div>

                          {/* Price */}
                          <div className="text-right">
                            <div className="text-sm text-gray-500">
                              ${item.price.toLocaleString('es-MX')} c/u
                            </div>
                            <div className="text-lg font-semibold text-gray-900">
                              ${itemTotal.toLocaleString('es-MX')}
                            </div>
                          </div>
                        </div>

                        {/* Stock warning */}
                        {item.cartQuantity >= item.stock && (
                          <Alert className="mt-3">
                            <AlertDescription className="text-sm">
                              Has alcanzado el stock máximo disponible para este producto.
                            </AlertDescription>
                          </Alert>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
            
            {/* Continue shopping */}
            <div className="pt-4">
              <Button variant="outline" asChild>
                <Link to="/productos">
                  <Package className="h-4 w-4 mr-2" />
                  Continuar Comprando
                </Link>
              </Button>
            </div>
          </div>

          {/* Order summary */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Resumen del Pedido</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span>Subtotal ({state.cart.itemCount} productos)</span>
                  <span>${subtotal.toLocaleString('es-MX')}</span>
                </div>
                
                <div className="flex justify-between">
                  <span>Envío</span>
                  <span>
                    {shipping === 0 ? (
                      <span className="text-green-600 font-medium">Gratis</span>
                    ) : (
                      `$${shipping.toLocaleString('es-MX')}`
                    )}
                  </span>
                </div>
                
                <div className="flex justify-between text-sm text-gray-600">
                  <span>IVA (16%)</span>
                  <span>${tax.toLocaleString('es-MX')}</span>
                </div>
                
                <div className="border-t pt-4">
                  <div className="flex justify-between text-lg font-semibold">
                    <span>Total</span>
                    <span>${total.toLocaleString('es-MX')}</span>
                  </div>
                </div>

                <Button 
                  onClick={proceedToCheckout}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  size="lg"
                >
                  <ArrowRight className="h-5 w-5 mr-2" />
                  Proceder al Checkout
                </Button>

                {shipping > 0 && (
                  <div className="text-center text-sm text-gray-600">
                    <p>Envío gratis en pedidos mayores a $5,000</p>
                    <p className="text-green-600 font-medium">
                      Te faltan ${(5000 - subtotal).toLocaleString('es-MX')} para envío gratis
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Services info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Servicios Incluidos</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3 text-sm">
                  <Truck className="h-4 w-4 text-blue-500" />
                  <span>Envío gratuito en La Laguna</span>
                </div>
                <div className="flex items-center space-x-3 text-sm">
                  <Shield className="h-4 w-4 text-green-500" />
                  <span>Garantía oficial incluida</span>
                </div>
                <div className="flex items-center space-x-3 text-sm">
                  <Calculator className="h-4 w-4 text-purple-500" />
                  <span>Asesoría técnica gratuita</span>
                </div>
              </CardContent>
            </Card>

            {/* Contact for quotes */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">¿Necesitas una cotización personalizada?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-3">
                  Contáctanos para precios especiales en compras al mayoreo
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  <Calculator className="h-4 w-4 mr-2" />
                  Solicitar Cotización
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default CartPage;
