import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, Grid3X3, List, SortAsc } from 'lucide-react';
import Layout from '../components/layout/Layout';
import ProductGrid from '../components/products/ProductGrid';
import { useProductsFiltered } from '../hooks/useProducts';
import { SearchFilters } from '../types';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '../components/ui/sheet';
import { Checkbox } from '../components/ui/checkbox';
import { Label } from '../components/ui/label';

const ProductsPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [filters, setFilters] = useState<SearchFilters>({
    query: searchParams.get('q') || '',
    category: searchParams.get('categoria') || '',
    brand: searchParams.get('marca') || '',
    minPrice: Number(searchParams.get('precio_min')) || undefined,
    maxPrice: Number(searchParams.get('precio_max')) || undefined,
    inStock: searchParams.get('disponible') === 'true',
    featured: searchParams.get('destacados') === 'true',
  });

  const { products, categories, brands, loading, error } = useProductsFiltered(filters);
  const [sortBy, setSortBy] = useState('name');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Update filters when URL params change
  useEffect(() => {
    setFilters({
      query: searchParams.get('q') || '',
      category: searchParams.get('categoria') || '',
      brand: searchParams.get('marca') || '',
      minPrice: Number(searchParams.get('precio_min')) || undefined,
      maxPrice: Number(searchParams.get('precio_max')) || undefined,
      inStock: searchParams.get('disponible') === 'true',
      featured: searchParams.get('destacados') === 'true',
    });
  }, [searchParams]);

  const updateFilters = (newFilters: Partial<SearchFilters>) => {
    const updatedFilters = { ...filters, ...newFilters };
    setFilters(updatedFilters);

    // Update URL params
    const params = new URLSearchParams();
    if (updatedFilters.query) params.set('q', updatedFilters.query);
    if (updatedFilters.category) params.set('categoria', updatedFilters.category);
    if (updatedFilters.brand) params.set('marca', updatedFilters.brand);
    if (updatedFilters.minPrice) params.set('precio_min', updatedFilters.minPrice.toString());
    if (updatedFilters.maxPrice) params.set('precio_max', updatedFilters.maxPrice.toString());
    if (updatedFilters.inStock) params.set('disponible', 'true');
    if (updatedFilters.featured) params.set('destacados', 'true');

    setSearchParams(params);
  };

  const clearFilters = () => {
    setFilters({ query: '' });
    setSearchParams(new URLSearchParams());
  };

  const sortedProducts = React.useMemo(() => {
    if (!products) return [];

    const sorted = [...products];
    switch (sortBy) {
      case 'price-asc':
        return sorted.sort((a, b) => a.price - b.price);
      case 'price-desc':
        return sorted.sort((a, b) => b.price - a.price);
      case 'name':
        return sorted.sort((a, b) => a.name.localeCompare(b.name, 'es'));
      case 'featured':
        return sorted.sort((a, b) => (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0));
      default:
        return sorted;
    }
  }, [products, sortBy]);

  const FilterContent = () => (
    <div className="space-y-6">
      {/* Search */}
      <div>
        <Label htmlFor="search" className="text-sm font-medium">
          Buscar
        </Label>
        <Input
          id="search"
          placeholder="Buscar productos..."
          value={filters.query || ''}
          onChange={(e) => updateFilters({ query: e.target.value })}
          className="mt-1"
        />
      </div>

      {/* Categories */}
      <div>
        <Label className="text-sm font-medium mb-3 block">Categorías</Label>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="all-categories"
              checked={!filters.category}
              onCheckedChange={() => updateFilters({ category: '' })}
            />
            <Label htmlFor="all-categories" className="text-sm">
              Todas las categorías
            </Label>
          </div>
          {categories.filter(cat => !cat.parentId).map((category) => (
            <div key={category.id} className="flex items-center space-x-2">
              <Checkbox
                id={category.id}
                checked={filters.category === category.id}
                onCheckedChange={() => 
                  updateFilters({ 
                    category: filters.category === category.id ? '' : category.id 
                  })
                }
              />
              <Label htmlFor={category.id} className="text-sm">
                {category.name}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {/* Brands */}
      <div>
        <Label className="text-sm font-medium mb-3 block">Marcas</Label>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="all-brands"
              checked={!filters.brand}
              onCheckedChange={() => updateFilters({ brand: '' })}
            />
            <Label htmlFor="all-brands" className="text-sm">
              Todas las marcas
            </Label>
          </div>
          {brands.map((brand) => (
            <div key={brand.id} className="flex items-center space-x-2">
              <Checkbox
                id={brand.id}
                checked={filters.brand === brand.id}
                onCheckedChange={() => 
                  updateFilters({ 
                    brand: filters.brand === brand.id ? '' : brand.id 
                  })
                }
              />
              <Label htmlFor={brand.id} className="text-sm">
                {brand.name}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {/* Price Range */}
      <div>
        <Label className="text-sm font-medium mb-3 block">Rango de Precio</Label>
        <div className="space-y-2">
          <Input
            placeholder="Precio mínimo"
            type="number"
            value={filters.minPrice || ''}
            onChange={(e) => updateFilters({ minPrice: Number(e.target.value) || undefined })}
          />
          <Input
            placeholder="Precio máximo"
            type="number"
            value={filters.maxPrice || ''}
            onChange={(e) => updateFilters({ maxPrice: Number(e.target.value) || undefined })}
          />
        </div>
      </div>

      {/* Availability */}
      <div className="space-y-2">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="in-stock"
            checked={filters.inStock || false}
            onCheckedChange={(checked) => updateFilters({ inStock: checked as boolean })}
          />
          <Label htmlFor="in-stock" className="text-sm">
            Solo productos en stock
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <Checkbox
            id="featured"
            checked={filters.featured || false}
            onCheckedChange={(checked) => updateFilters({ featured: checked as boolean })}
          />
          <Label htmlFor="featured" className="text-sm">
            Solo productos destacados
          </Label>
        </div>
      </div>

      {/* Clear Filters */}
      <Button variant="outline" onClick={clearFilters} className="w-full">
        Limpiar Filtros
      </Button>
    </div>
  );

  if (error) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-red-600 mb-4">Error</h1>
            <p className="text-gray-600">{error}</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {filters.query ? `Resultados para "${filters.query}"` : 'Todos los Productos'}
          </h1>
          <p className="text-gray-600">
            {loading ? 'Cargando...' : `${sortedProducts.length} productos encontrados`}
          </p>
        </div>

        {/* Filters and Controls */}
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters - Desktop */}
          <div className="hidden lg:block w-64 flex-shrink-0">
            <div className="bg-white p-6 rounded-lg border border-gray-200">
              <h2 className="text-lg font-semibold mb-4">Filtros</h2>
              <FilterContent />
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Top Controls */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
              {/* Mobile Filters */}
              <div className="flex items-center space-x-4">
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="outline" className="lg:hidden">
                      <Filter className="h-4 w-4 mr-2" />
                      Filtros
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-80">
                    <SheetHeader>
                      <SheetTitle>Filtros</SheetTitle>
                      <SheetDescription>
                        Filtra productos por categoría, marca, precio y más
                      </SheetDescription>
                    </SheetHeader>
                    <div className="mt-6">
                      <FilterContent />
                    </div>
                  </SheetContent>
                </Sheet>

                {/* View Mode Toggle */}
                <div className="flex rounded-lg border border-gray-200">
                  <Button
                    variant={viewMode === 'grid' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setViewMode('grid')}
                    className="rounded-r-none"
                  >
                    <Grid3X3 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === 'list' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setViewMode('list')}
                    className="rounded-l-none"
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Sort */}
              <div className="flex items-center space-x-2">
                <SortAsc className="h-4 w-4 text-gray-500" />
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Ordenar por" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name">Nombre A-Z</SelectItem>
                    <SelectItem value="price-asc">Precio: Menor a Mayor</SelectItem>
                    <SelectItem value="price-desc">Precio: Mayor a Menor</SelectItem>
                    <SelectItem value="featured">Destacados</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Products Grid */}
            <ProductGrid
              products={sortedProducts}
              brands={brands}
              categories={categories}
              loading={loading}
              columns={viewMode === 'grid' ? 3 : 2}
            />
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ProductsPage;
