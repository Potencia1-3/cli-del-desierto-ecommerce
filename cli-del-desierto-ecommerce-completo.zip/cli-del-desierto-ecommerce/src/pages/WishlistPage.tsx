import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Heart, 
  ShoppingCart, 
  Trash2, 
  Package, 
  Share2, 
  Filter,
  Grid3X3,
  List,
  Star,
  Calculator
} from 'lucide-react';
import Layout from '../components/layout/Layout';
import ProductCard from '../components/products/ProductCard';
import { useApp } from '../context/AppContext';
import { useProducts } from '../hooks/useProducts';
import { Product } from '../types';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import { Checkbox } from '../components/ui/checkbox';
import { Alert, AlertDescription } from '../components/ui/alert';

const WishlistPage: React.FC = () => {
  const { state, removeFromWishlist, addToCart } = useApp();
  const { products, brands, categories } = useProducts();
  
  const [wishlistProducts, setWishlistProducts] = useState<Product[]>([]);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState('dateAdded');
  const [filterBy, setFilterBy] = useState('all');
  const [loading, setLoading] = useState(true);

  // Load wishlist products
  useEffect(() => {
    if (products.length > 0) {
      const favoriteProducts = products.filter(product => 
        state.wishlist.includes(product.id)
      );
      setWishlistProducts(favoriteProducts);
      setLoading(false);
    }
  }, [products, state.wishlist]);

  // Sort products
  const sortedProducts = React.useMemo(() => {
    const sorted = [...wishlistProducts];
    
    switch (sortBy) {
      case 'name':
        return sorted.sort((a, b) => a.name.localeCompare(b.name, 'es'));
      case 'priceAsc':
        return sorted.sort((a, b) => a.price - b.price);
      case 'priceDesc':
        return sorted.sort((a, b) => b.price - a.price);
      case 'brand':
        return sorted.sort((a, b) => {
          const brandA = brands.find(brand => brand.id === a.brandId)?.name || '';
          const brandB = brands.find(brand => brand.id === b.brandId)?.name || '';
          return brandA.localeCompare(brandB, 'es');
        });
      case 'dateAdded':
      default:
        // For demo, we'll reverse to show recently added first
        return sorted.reverse();
    }
  }, [wishlistProducts, sortBy, brands]);

  // Filter products
  const filteredProducts = React.useMemo(() => {
    switch (filterBy) {
      case 'inStock':
        return sortedProducts.filter(product => product.stock > 0);
      case 'onSale':
        return sortedProducts.filter(product => product.comparePrice > product.price);
      case 'featured':
        return sortedProducts.filter(product => product.isFeatured);
      case 'all':
      default:
        return sortedProducts;
    }
  }, [sortedProducts, filterBy]);

  const handleRemoveSelected = () => {
    selectedItems.forEach(productId => {
      removeFromWishlist(productId);
    });
    setSelectedItems([]);
  };

  const handleAddSelectedToCart = () => {
    const inStockSelected = selectedItems.filter(productId => {
      const product = products.find(p => p.id === productId);
      return product && product.stock > 0;
    });

    inStockSelected.forEach(productId => {
      const product = products.find(p => p.id === productId);
      if (product) {
        addToCart(productId, 1, product.price);
      }
    });

    setSelectedItems([]);
  };

  const handleSelectAll = () => {
    if (selectedItems.length === filteredProducts.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(filteredProducts.map(p => p.id));
    }
  };

  const handleItemSelect = (productId: string) => {
    setSelectedItems(prev => 
      prev.includes(productId)
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const shareWishlist = () => {
    const url = window.location.href;
    if (navigator.share) {
      navigator.share({
        title: 'Mi Lista de Favoritos - Clí+ Del Desierto',
        text: 'Mira los productos que me gustan en Clí+ Del Desierto',
        url: url,
      });
    } else {
      navigator.clipboard.writeText(url);
      // Show toast notification
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="h-80 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (wishlistProducts.length === 0) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <div className="text-center max-w-md mx-auto">
            <Heart className="h-24 w-24 text-gray-300 mx-auto mb-6" />
            <h1 className="text-2xl font-bold text-gray-900 mb-4">
              Tu lista de favoritos está vacía
            </h1>
            <p className="text-gray-600 mb-8">
              Guarda los productos que te interesan para encontrarlos fácilmente más tarde
            </p>
            <Button asChild size="lg">
              <Link to="/productos">
                <Package className="h-5 w-5 mr-2" />
                Explorar Productos
              </Link>
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <Heart className="h-8 w-8 text-red-500 mr-3 fill-current" />
              Mis Favoritos
            </h1>
            <p className="text-gray-600 mt-1">
              {wishlistProducts.length} producto{wishlistProducts.length !== 1 ? 's' : ''} guardado{wishlistProducts.length !== 1 ? 's' : ''}
            </p>
          </div>
          
          <Button variant="outline" onClick={shareWishlist}>
            <Share2 className="h-4 w-4 mr-2" />
            Compartir Lista
          </Button>
        </div>

        {/* Bulk actions */}
        {selectedItems.length > 0 && (
          <Alert className="mb-6">
            <AlertDescription className="flex items-center justify-between">
              <span>
                {selectedItems.length} producto{selectedItems.length !== 1 ? 's' : ''} seleccionado{selectedItems.length !== 1 ? 's' : ''}
              </span>
              <div className="flex space-x-2">
                <Button
                  size="sm"
                  onClick={handleAddSelectedToCart}
                  disabled={!selectedItems.some(id => {
                    const product = products.find(p => p.id === id);
                    return product && product.stock > 0;
                  })}
                >
                  <ShoppingCart className="h-4 w-4 mr-1" />
                  Agregar al Carrito
                </Button>
                <Button size="sm" variant="outline" onClick={handleRemoveSelected}>
                  <Trash2 className="h-4 w-4 mr-1" />
                  Eliminar
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Controls */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div className="flex items-center space-x-4">
            {/* Select all */}
            <div className="flex items-center space-x-2">
              <Checkbox
                id="selectAll"
                checked={selectedItems.length === filteredProducts.length && filteredProducts.length > 0}
                onCheckedChange={handleSelectAll}
              />
              <label htmlFor="selectAll" className="text-sm font-medium">
                Seleccionar todo
              </label>
            </div>

            {/* View mode */}
            <div className="flex rounded-lg border border-gray-200">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="rounded-r-none"
              >
                <Grid3X3 className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="rounded-l-none"
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {/* Filter */}
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <Select value={filterBy} onValueChange={setFilterBy}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="inStock">Disponibles</SelectItem>
                  <SelectItem value="onSale">En Oferta</SelectItem>
                  <SelectItem value="featured">Destacados</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Sort */}
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dateAdded">Agregados Recientemente</SelectItem>
                <SelectItem value="name">Nombre A-Z</SelectItem>
                <SelectItem value="priceAsc">Precio: Menor a Mayor</SelectItem>
                <SelectItem value="priceDesc">Precio: Mayor a Menor</SelectItem>
                <SelectItem value="brand">Marca</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Products */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-12">
            <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No hay productos que coincidan con el filtro
            </h3>
            <p className="text-gray-500">
              Prueba cambiando los filtros para ver más productos
            </p>
          </div>
        ) : viewMode === 'grid' ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product) => {
              const brand = brands.find(b => b.id === product.brandId);
              const category = categories.find(c => c.id === product.categoryId);
              
              return (
                <div key={product.id} className="relative">
                  <div className="absolute top-2 left-2 z-10">
                    <Checkbox
                      checked={selectedItems.includes(product.id)}
                      onCheckedChange={() => handleItemSelect(product.id)}
                      className="bg-white border-2"
                    />
                  </div>
                  <ProductCard
                    product={product}
                    brand={brand}
                    category={category}
                  />
                </div>
              );
            })}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredProducts.map((product) => {
              const brand = brands.find(b => b.id === product.brandId);
              const isInStock = product.stock > 0;
              const discountPercentage = product.comparePrice > product.price 
                ? Math.round(((product.comparePrice - product.price) / product.comparePrice) * 100)
                : 0;

              return (
                <Card key={product.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex space-x-4">
                      {/* Checkbox */}
                      <div className="flex-shrink-0 pt-2">
                        <Checkbox
                          checked={selectedItems.includes(product.id)}
                          onCheckedChange={() => handleItemSelect(product.id)}
                        />
                      </div>

                      {/* Product image */}
                      <div className="flex-shrink-0">
                        <Link to={`/producto/${product.id}`}>
                          <div className="w-24 h-24 bg-gray-100 rounded-lg overflow-hidden">
                            {product.images && product.images.length > 0 ? (
                              <img
                                src={product.images[0]}
                                alt={product.name}
                                className="w-full h-full object-cover hover:scale-105 transition-transform"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <Package className="h-8 w-8 text-gray-400" />
                              </div>
                            )}
                          </div>
                        </Link>
                      </div>

                      {/* Product details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              {brand && (
                                <Badge variant="secondary">{brand.name}</Badge>
                              )}
                              {product.isFeatured && (
                                <Badge className="bg-yellow-50 text-yellow-700">
                                  <Star className="h-3 w-3 mr-1" />
                                  Destacado
                                </Badge>
                              )}
                              {discountPercentage > 0 && (
                                <Badge className="bg-red-500 text-white">
                                  -{discountPercentage}%
                                </Badge>
                              )}
                            </div>
                            
                            <h3 className="font-medium text-gray-900 line-clamp-2 mb-2">
                              <Link 
                                to={`/producto/${product.id}`}
                                className="hover:text-blue-600 transition-colors"
                              >
                                {product.name}
                              </Link>
                            </h3>
                            
                            <p className="text-sm text-gray-600 line-clamp-2 mb-2">
                              {product.shortDescription}
                            </p>

                            {/* Key specs */}
                            {product.specifications?.btus && (
                              <p className="text-sm text-gray-500">
                                {product.specifications.btus}
                              </p>
                            )}
                          </div>

                          {/* Price and actions */}
                          <div className="text-right ml-4">
                            <div className="mb-2">
                              {product.comparePrice > product.price && (
                                <span className="text-sm text-gray-400 line-through block">
                                  ${product.comparePrice.toLocaleString('es-MX')}
                                </span>
                              )}
                              <span className="text-xl font-bold text-gray-900">
                                ${product.price.toLocaleString('es-MX')}
                              </span>
                            </div>

                            <div className="space-y-2">
                              {isInStock ? (
                                <Button
                                  size="sm"
                                  onClick={() => addToCart(product.id, 1, product.price)}
                                  className="w-full"
                                >
                                  <ShoppingCart className="h-4 w-4 mr-2" />
                                  Agregar
                                </Button>
                              ) : (
                                <Button size="sm" disabled className="w-full">
                                  Sin stock
                                </Button>
                              )}
                              
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => removeFromWishlist(product.id)}
                                className="w-full text-red-600 hover:text-red-700"
                              >
                                <Heart className="h-4 w-4 mr-2 fill-current" />
                                Quitar
                              </Button>
                            </div>

                            {!isInStock && (
                              <p className="text-xs text-red-600 mt-1">
                                Sin stock
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Quick actions */}
        {wishlistProducts.length > 0 && (
          <div className="mt-12 bg-gray-50 p-6 rounded-lg">
            <h3 className="font-semibold mb-4">Acciones Rápidas</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <Button variant="outline" size="sm" onClick={shareWishlist}>
                <Share2 className="h-4 w-4 mr-2" />
                Compartir Lista
              </Button>
              <Button variant="outline" size="sm">
                <Calculator className="h-4 w-4 mr-2" />
                Cotizar Todo
              </Button>
              <Button variant="outline" size="sm" onClick={() => setSelectedItems(wishlistProducts.map(p => p.id))}>
                <ShoppingCart className="h-4 w-4 mr-2" />
                Seleccionar Todo
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  if (window.confirm('¿Estás seguro de que quieres limpiar toda tu lista de favoritos?')) {
                    wishlistProducts.forEach(product => removeFromWishlist(product.id));
                  }
                }}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Limpiar Lista
              </Button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default WishlistPage;
