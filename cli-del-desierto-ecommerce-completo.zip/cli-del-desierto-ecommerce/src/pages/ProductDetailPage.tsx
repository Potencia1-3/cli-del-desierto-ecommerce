import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  Heart, 
  ShoppingCart, 
  Star, 
  Package, 
  Zap, 
  Shield, 
  Plus, 
  Minus, 
  ArrowLeft, 
  Share2,
  Truck,
  RotateCcw,
  Calculator,
  MessageCircle,
  Phone
} from 'lucide-react';
import Layout from '../components/layout/Layout';
import ProductGrid from '../components/products/ProductGrid';
import { useProduct, useRelatedProducts } from '../hooks/useProducts';
import { useApp } from '../context/AppContext';
import { useCompany } from '../hooks/useCompany';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Alert, AlertDescription } from '../components/ui/alert';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { product, brand, category, loading, error } = useProduct(id || '');
  const { relatedProducts } = useRelatedProducts(id || '', 4);
  const { state, addToCart, addToWishlist, removeFromWishlist } = useApp();
  const { company } = useCompany();
  
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [showQuoteForm, setShowQuoteForm] = useState(false);

  const isInWishlist = product ? state.wishlist.includes(product.id) : false;
  const isInStock = product ? product.stock > 0 : false;
  
  const discountPercentage = product && product.comparePrice > product.price 
    ? Math.round(((product.comparePrice - product.price) / product.comparePrice) * 100)
    : 0;

  const handleAddToCart = () => {
    if (product && isInStock) {
      addToCart(product.id, quantity, product.price);
      // Show success message or feedback
    }
  };

  const handleWishlistToggle = () => {
    if (product) {
      if (isInWishlist) {
        removeFromWishlist(product.id);
      } else {
        addToWishlist(product.id);
      }
    }
  };

  const handleQuantityChange = (change: number) => {
    const newQuantity = Math.max(1, Math.min(product?.stock || 1, quantity + change));
    setQuantity(newQuantity);
  };

  const handleRequestQuote = () => {
    setShowQuoteForm(true);
  };

  if (loading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-6">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="aspect-square bg-gray-200 rounded-lg"></div>
              <div className="space-y-4">
                <div className="h-8 bg-gray-200 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                <div className="h-6 bg-gray-200 rounded w-1/4"></div>
                <div className="h-12 bg-gray-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (error || !product) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-red-600 mb-4">Producto no encontrado</h1>
            <p className="text-gray-600 mb-4">El producto que buscas no existe o ha sido removido.</p>
            <Button onClick={() => navigate('/productos')}>
              Ver todos los productos
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center space-x-2 text-sm text-gray-500 mb-6">
          <Link to="/" className="hover:text-blue-600">Inicio</Link>
          <span>/</span>
          {category && (
            <>
              <Link to={`/categoria/${category.id}`} className="hover:text-blue-600">
                {category.name}
              </Link>
              <span>/</span>
            </>
          )}
          <span className="text-gray-900">{product.name}</span>
        </div>

        {/* Back button */}
        <Button 
          variant="ghost" 
          onClick={() => navigate(-1)}
          className="mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Volver
        </Button>

        {/* Product details */}
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Images */}
          <div className="space-y-4">
            <div className="aspect-square rounded-lg overflow-hidden bg-gray-100">
              {product.images && product.images.length > 0 ? (
                <img
                  src={product.images[selectedImage]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iI2Y4ZjlmYSIvPgogIDxwYXRoIGQ9Ik0xMDAgNzBjLTE2LjU2OSAwLTMwIDEzLjQzMS0zMCAzMHMxMy40MzEgMzAgMzAgMzAgMzAtMTMuNDMxIDMwLTMwLTEzLjQzMS0zMC0zMC0zMHptMCA0NWMtOC4yODQgMC0xNS02Ljc1My0xNS0xNSAwLTguMjg0IDYuNzE2LTE1IDE1LTE1czE1IDYuNzE2IDE1IDE1Yy4wMzggOC4yNDctNi43NTMgMTUtMTUgMTV6bTAtMjVjLTUuNTIzIDAtMTAgNC40NzctMTAgMTBzNC40NzcgMTAgMTAgMTAgMTAtNC40NzcgMTAtMTAtNC40NzctMTAtMTAtMTB6Ii8+Cjwvc3ZnPgo=';
                  }}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Package className="h-24 w-24 text-gray-400" />
                </div>
              )}
            </div>
            
            {/* Thumbnail images */}
            {product.images && product.images.length > 1 && (
              <div className="grid grid-cols-4 gap-2">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`aspect-square rounded-lg overflow-hidden border-2 ${
                      selectedImage === index ? 'border-blue-500' : 'border-gray-200'
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product info */}
          <div className="space-y-6">
            {/* Brand and badges */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                {brand && (
                  <Badge className="bg-blue-50 text-blue-700 hover:bg-blue-100">
                    {brand.name}
                  </Badge>
                )}
                {product.isFeatured && (
                  <Badge className="bg-yellow-50 text-yellow-700 hover:bg-yellow-100">
                    <Star className="h-3 w-3 mr-1" />
                    Destacado
                  </Badge>
                )}
                {discountPercentage > 0 && (
                  <Badge className="bg-red-500 text-white">
                    -{discountPercentage}% OFF
                  </Badge>
                )}
              </div>
              
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleWishlistToggle}
                  className={isInWishlist ? 'text-red-500 border-red-200' : ''}
                >
                  <Heart className={`h-4 w-4 ${isInWishlist ? 'fill-current' : ''}`} />
                </Button>
                <Button variant="outline" size="sm">
                  <Share2 className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Product name and description */}
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {product.name}
              </h1>
              <p className="text-lg text-gray-600">
                {product.shortDescription}
              </p>
              <p className="text-sm text-gray-500 mt-2">
                SKU: {product.sku}
              </p>
            </div>

            {/* Key specifications */}
            {product.specifications && (
              <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                {product.specifications.btus && (
                  <div className="flex items-center">
                    <Zap className="h-4 w-4 text-yellow-500 mr-2" />
                    <span className="text-sm font-medium">{product.specifications.btus}</span>
                  </div>
                )}
                {product.specifications.voltage && (
                  <div className="text-sm">
                    <span className="font-medium">Voltaje:</span> {product.specifications.voltage}
                  </div>
                )}
                {product.specifications.warranty && (
                  <div className="flex items-center">
                    <Shield className="h-4 w-4 text-green-500 mr-2" />
                    <span className="text-sm font-medium">Garantía: {product.specifications.warranty}</span>
                  </div>
                )}
                {product.specifications.coverage && (
                  <div className="text-sm">
                    <span className="font-medium">Cobertura:</span> {product.specifications.coverage}
                  </div>
                )}
              </div>
            )}

            {/* Price */}
            <div className="space-y-2">
              {product.comparePrice > product.price && (
                <span className="text-lg text-gray-400 line-through">
                  ${product.comparePrice.toLocaleString('es-MX')}
                </span>
              )}
              <div className="flex items-baseline space-x-2">
                <span className="text-4xl font-bold text-gray-900">
                  ${product.price.toLocaleString('es-MX')}
                </span>
                {discountPercentage > 0 && (
                  <span className="text-lg font-medium text-green-600">
                    Ahorras ${(product.comparePrice - product.price).toLocaleString('es-MX')}
                  </span>
                )}
              </div>
            </div>

            {/* Stock and availability */}
            <div className="flex items-center space-x-4">
              {isInStock ? (
                <>
                  <div className="flex items-center text-green-600">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <span className="font-medium">Disponible</span>
                  </div>
                  {product.stock <= 5 && (
                    <span className="text-orange-600 text-sm">
                      ¡Últimas {product.stock} unidades!
                    </span>
                  )}
                </>
              ) : (
                <div className="flex items-center text-red-600">
                  <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
                  <span className="font-medium">Sin stock</span>
                </div>
              )}
            </div>

            {/* Quantity selector and actions */}
            {isInStock && (
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <span className="text-sm font-medium">Cantidad:</span>
                  <div className="flex items-center border border-gray-300 rounded-lg">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleQuantityChange(-1)}
                      disabled={quantity <= 1}
                      className="px-3 py-1"
                    >
                      <Minus className="h-3 w-3" />
                    </Button>
                    <span className="px-4 py-2 text-center min-w-[60px]">{quantity}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleQuantityChange(1)}
                      disabled={quantity >= product.stock}
                      className="px-3 py-1"
                    >
                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>
                  <span className="text-sm text-gray-500">
                    {product.stock} disponibles
                  </span>
                </div>

                <div className="flex space-x-3">
                  <Button
                    onClick={handleAddToCart}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                    size="lg"
                  >
                    <ShoppingCart className="h-5 w-5 mr-2" />
                    Agregar al Carrito
                  </Button>
                  <Button
                    variant="outline"
                    onClick={handleRequestQuote}
                    size="lg"
                    className="flex-1"
                  >
                    <Calculator className="h-5 w-5 mr-2" />
                    Solicitar Cotización
                  </Button>
                </div>
              </div>
            )}

            {/* Contact options */}
            <div className="border-t pt-6">
              <h3 className="font-semibold mb-3">¿Necesitas ayuda?</h3>
              <div className="grid grid-cols-2 gap-3">
                <a
                  href={`tel:${company?.phone?.replace(/\s/g, '')}`}
                  className="flex items-center justify-center space-x-2 bg-blue-50 hover:bg-blue-100 text-blue-700 p-3 rounded-lg transition-colors"
                >
                  <Phone className="h-4 w-4" />
                  <span className="text-sm font-medium">Llamar</span>
                </a>
                <a
                  href={company?.socialMedia?.whatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center space-x-2 bg-green-50 hover:bg-green-100 text-green-700 p-3 rounded-lg transition-colors"
                >
                  <MessageCircle className="h-4 w-4" />
                  <span className="text-sm font-medium">WhatsApp</span>
                </a>
              </div>
            </div>

            {/* Services */}
            <div className="space-y-3">
              <div className="flex items-center space-x-3 text-sm text-gray-600">
                <Truck className="h-4 w-4 text-blue-500" />
                <span>Envío gratuito en Torreón y La Laguna</span>
              </div>
              <div className="flex items-center space-x-3 text-sm text-gray-600">
                <Shield className="h-4 w-4 text-green-500" />
                <span>Garantía oficial de {product.specifications?.warranty || '1 año'}</span>
              </div>
              <div className="flex items-center space-x-3 text-sm text-gray-600">
                <RotateCcw className="h-4 w-4 text-purple-500" />
                <span>30 días para cambios y devoluciones</span>
              </div>
            </div>
          </div>
        </div>

        {/* Product tabs */}
        <div className="mt-16">
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="description">Descripción</TabsTrigger>
              <TabsTrigger value="specifications">Especificaciones</TabsTrigger>
              <TabsTrigger value="reviews">Reseñas</TabsTrigger>
            </TabsList>
            
            <TabsContent value="description" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Descripción del Producto</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 leading-relaxed">
                    {product.description}
                  </p>
                  
                  {product.tags && product.tags.length > 0 && (
                    <div className="mt-6">
                      <h4 className="font-medium mb-3">Características destacadas:</h4>
                      <div className="flex flex-wrap gap-2">
                        {product.tags.map((tag) => (
                          <Badge key={tag} variant="secondary">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="specifications" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Especificaciones Técnicas</CardTitle>
                </CardHeader>
                <CardContent>
                  {product.specifications ? (
                    <div className="grid md:grid-cols-2 gap-4">
                      {Object.entries(product.specifications).map(([key, value]) => (
                        <div key={key} className="flex justify-between py-2 border-b border-gray-100">
                          <span className="font-medium capitalize">
                            {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}:
                          </span>
                          <span className="text-gray-700">{value}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500">
                      No hay especificaciones técnicas disponibles para este producto.
                    </p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="reviews" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Reseñas de Clientes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <Star className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500 mb-4">
                      Aún no hay reseñas para este producto.
                    </p>
                    <p className="text-sm text-gray-400">
                      ¡Sé el primero en dejar una reseña después de tu compra!
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Related products */}
        {relatedProducts.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">
              Productos Relacionados
            </h2>
            <ProductGrid
              products={relatedProducts}
              columns={4}
            />
          </div>
        )}

        {/* Quote form modal */}
        {showQuoteForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-md w-full p-6">
              <h3 className="text-lg font-semibold mb-4">Solicitar Cotización</h3>
              <Alert>
                <AlertDescription>
                  Para solicitar una cotización personalizada de este producto, por favor contactanos:
                </AlertDescription>
              </Alert>
              <div className="mt-4 space-y-3">
                <a
                  href={`tel:${company?.phone?.replace(/\s/g, '')}`}
                  className="flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-lg transition-colors"
                >
                  <Phone className="h-4 w-4" />
                  <span>Llamar {company?.phone}</span>
                </a>
                <a
                  href={company?.socialMedia?.whatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center space-x-2 bg-green-600 hover:bg-green-700 text-white p-3 rounded-lg transition-colors"
                >
                  <MessageCircle className="h-4 w-4" />
                  <span>WhatsApp</span>
                </a>
              </div>
              <Button
                variant="outline"
                onClick={() => setShowQuoteForm(false)}
                className="w-full mt-4"
              >
                Cerrar
              </Button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default ProductDetailPage;
