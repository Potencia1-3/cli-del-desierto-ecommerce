import React from 'react';
import Layout from '../components/layout/Layout';
import { useApp } from '../context/AppContext';

const ProfilePage: React.FC = () => {
  const { state } = useApp();

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Mi Perfil</h1>
        {state.auth.user && (
          <div className="bg-white p-6 rounded-lg border">
            <h2 className="text-xl font-semibold mb-4">Información Personal</h2>
            <p><strong>Nombre:</strong> {state.auth.user.firstName} {state.auth.user.lastName}</p>
            <p><strong>Email:</strong> {state.auth.user.email}</p>
            <p><strong>Teléfono:</strong> {state.auth.user.phone}</p>
            <p><strong>Rol:</strong> {state.auth.user.role}</p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default ProfilePage;
