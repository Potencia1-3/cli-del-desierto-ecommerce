import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  CreditCard, 
  MapPin, 
  User, 
  Phone, 
  Mail, 
  Package, 
  Shield, 
  CheckCircle, 
  ArrowLeft,
  Building,
  Truck
} from 'lucide-react';
import Layout from '../components/layout/Layout';
import { useApp } from '../context/AppContext';
import { useProducts } from '../hooks/useProducts';
import { Product } from '../types';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { Checkbox } from '../components/ui/checkbox';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Badge } from '../components/ui/badge';

interface CheckoutFormData {
  // Personal info
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  
  // Shipping address
  shippingAddress: {
    street: string;
    number: string;
    colony: string;
    city: string;
    state: string;
    zipCode: string;
    references: string;
  };
  
  // Billing
  needsInvoice: boolean;
  billingAddress: {
    companyName: string;
    rfc: string;
    street: string;
    number: string;
    colony: string;
    city: string;
    state: string;
    zipCode: string;
  };
  
  // Payment
  paymentMethod: 'credit_card' | 'paypal' | 'oxxo' | 'transfer';
  cardInfo: {
    number: string;
    expiryMonth: string;
    expiryYear: string;
    cvv: string;
    holderName: string;
  };
}

const CheckoutPage: React.FC = () => {
  const { state, clearCart } = useApp();
  const { products } = useProducts();
  const navigate = useNavigate();
  
  const [cartProducts, setCartProducts] = useState<(Product & { cartQuantity: number })[]>([]);
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderId, setOrderId] = useState('');
  
  const [formData, setFormData] = useState<CheckoutFormData>({
    firstName: state.auth.user?.firstName || '',
    lastName: state.auth.user?.lastName || '',
    email: state.auth.user?.email || '',
    phone: state.auth.user?.phone || '',
    
    shippingAddress: {
      street: state.auth.user?.address?.street || '',
      number: '',
      colony: '',
      city: state.auth.user?.address?.city || 'Torreón',
      state: state.auth.user?.address?.state || 'Coahuila',
      zipCode: state.auth.user?.address?.zipCode || '',
      references: ''
    },
    
    needsInvoice: false,
    billingAddress: {
      companyName: '',
      rfc: '',
      street: '',
      number: '',
      colony: '',
      city: 'Torreón',
      state: 'Coahuila',
      zipCode: ''
    },
    
    paymentMethod: 'credit_card',
    cardInfo: {
      number: '',
      expiryMonth: '',
      expiryYear: '',
      cvv: '',
      holderName: ''
    }
  });

  // Load cart products
  useEffect(() => {
    if (products.length > 0 && state.cart.items.length > 0) {
      const enrichedItems = state.cart.items.map(cartItem => {
        const product = products.find(p => p.id === cartItem.productId);
        return product ? { ...product, cartQuantity: cartItem.quantity } : null;
      }).filter(Boolean) as (Product & { cartQuantity: number })[];
      
      setCartProducts(enrichedItems);
    }
  }, [products, state.cart.items]);

  // Redirect if cart is empty
  useEffect(() => {
    if (!state.cart.items.length && !orderPlaced) {
      navigate('/carrito');
    }
  }, [state.cart.items, navigate, orderPlaced]);

  const subtotal = state.cart.total;
  const shipping = subtotal > 5000 ? 0 : 500;
  const tax = subtotal * 0.16;
  const total = subtotal + shipping + tax;

  const handleInputChange = (field: string, value: string) => {
    const keys = field.split('.');
    setFormData(prev => {
      const newData = { ...prev };
      let current: any = newData;
      
      for (let i = 0; i < keys.length - 1; i++) {
        current = current[keys[i]];
      }
      current[keys[keys.length - 1]] = value;
      
      return newData;
    });
  };

  const validateStep = (stepNumber: number): boolean => {
    switch (stepNumber) {
      case 1:
        return !!(formData.firstName && formData.lastName && formData.email && formData.phone);
      case 2:
        return !!(formData.shippingAddress.street && formData.shippingAddress.city && formData.shippingAddress.zipCode);
      case 3:
        if (formData.paymentMethod === 'credit_card') {
          return !!(formData.cardInfo.number && formData.cardInfo.expiryMonth && formData.cardInfo.expiryYear && formData.cardInfo.cvv);
        }
        return true;
      default:
        return true;
    }
  };

  const handleNextStep = () => {
    if (validateStep(step)) {
      setStep(step + 1);
    }
  };

  const handleSubmitOrder = async () => {
    setLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Generate order ID
      const newOrderId = `CLI-${Date.now()}`;
      setOrderId(newOrderId);
      
      // Clear cart and show success
      clearCart();
      setOrderPlaced(true);
      setStep(4);
    } catch (error) {
      console.error('Error placing order:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderStep1 = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <User className="h-5 w-5 mr-2" />
          Información Personal
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="firstName">Nombre *</Label>
            <Input
              id="firstName"
              value={formData.firstName}
              onChange={(e) => handleInputChange('firstName', e.target.value)}
              placeholder="Tu nombre"
              required
            />
          </div>
          <div>
            <Label htmlFor="lastName">Apellidos *</Label>
            <Input
              id="lastName"
              value={formData.lastName}
              onChange={(e) => handleInputChange('lastName', e.target.value)}
              placeholder="Tus apellidos"
              required
            />
          </div>
        </div>
        
        <div>
          <Label htmlFor="email">Email *</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => handleInputChange('email', e.target.value)}
            placeholder="tu@email.com"
            required
          />
        </div>
        
        <div>
          <Label htmlFor="phone">Teléfono *</Label>
          <Input
            id="phone"
            type="tel"
            value={formData.phone}
            onChange={(e) => handleInputChange('phone', e.target.value)}
            placeholder="(871) 123-4567"
            required
          />
        </div>
      </CardContent>
    </Card>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <MapPin className="h-5 w-5 mr-2" />
            Dirección de Envío
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="col-span-2">
              <Label htmlFor="street">Calle *</Label>
              <Input
                id="street"
                value={formData.shippingAddress.street}
                onChange={(e) => handleInputChange('shippingAddress.street', e.target.value)}
                placeholder="Av. Revolución"
                required
              />
            </div>
            <div>
              <Label htmlFor="number">Número *</Label>
              <Input
                id="number"
                value={formData.shippingAddress.number}
                onChange={(e) => handleInputChange('shippingAddress.number', e.target.value)}
                placeholder="123"
                required
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="colony">Colonia</Label>
            <Input
              id="colony"
              value={formData.shippingAddress.colony}
              onChange={(e) => handleInputChange('shippingAddress.colony', e.target.value)}
              placeholder="Centro"
            />
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="city">Ciudad *</Label>
              <Input
                id="city"
                value={formData.shippingAddress.city}
                onChange={(e) => handleInputChange('shippingAddress.city', e.target.value)}
                placeholder="Torreón"
                required
              />
            </div>
            <div>
              <Label htmlFor="state">Estado *</Label>
              <Input
                id="state"
                value={formData.shippingAddress.state}
                onChange={(e) => handleInputChange('shippingAddress.state', e.target.value)}
                placeholder="Coahuila"
                required
              />
            </div>
            <div>
              <Label htmlFor="zipCode">Código Postal *</Label>
              <Input
                id="zipCode"
                value={formData.shippingAddress.zipCode}
                onChange={(e) => handleInputChange('shippingAddress.zipCode', e.target.value)}
                placeholder="27000"
                required
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="references">Referencias de entrega</Label>
            <Input
              id="references"
              value={formData.shippingAddress.references}
              onChange={(e) => handleInputChange('shippingAddress.references', e.target.value)}
              placeholder="Casa blanca con portón azul, entre calle A y B"
            />
          </div>
        </CardContent>
      </Card>

      {/* Invoice section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Building className="h-5 w-5 mr-2" />
            Facturación
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 mb-4">
            <Checkbox
              id="needsInvoice"
              checked={formData.needsInvoice}
              onCheckedChange={(checked) => handleInputChange('needsInvoice', checked ? 'true' : 'false')}
            />
            <Label htmlFor="needsInvoice">Necesito factura</Label>
          </div>
          
          {formData.needsInvoice && (
            <div className="space-y-4 border-t pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="companyName">Razón Social *</Label>
                  <Input
                    id="companyName"
                    value={formData.billingAddress.companyName}
                    onChange={(e) => handleInputChange('billingAddress.companyName', e.target.value)}
                    placeholder="Mi Empresa S.A. de C.V."
                    required={formData.needsInvoice}
                  />
                </div>
                <div>
                  <Label htmlFor="rfc">RFC *</Label>
                  <Input
                    id="rfc"
                    value={formData.billingAddress.rfc}
                    onChange={(e) => handleInputChange('billingAddress.rfc', e.target.value)}
                    placeholder="XAXX010101000"
                    required={formData.needsInvoice}
                  />
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );

  const renderStep3 = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <CreditCard className="h-5 w-5 mr-2" />
          Método de Pago
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <RadioGroup
          value={formData.paymentMethod}
          onValueChange={(value) => handleInputChange('paymentMethod', value)}
        >
          <div className="flex items-center space-x-2 p-3 border rounded-lg">
            <RadioGroupItem value="credit_card" id="credit_card" />
            <Label htmlFor="credit_card" className="flex items-center cursor-pointer">
              <CreditCard className="h-4 w-4 mr-2" />
              Tarjeta de Crédito/Débito
            </Label>
          </div>
          
          <div className="flex items-center space-x-2 p-3 border rounded-lg">
            <RadioGroupItem value="oxxo" id="oxxo" />
            <Label htmlFor="oxxo" className="flex items-center cursor-pointer">
              <Package className="h-4 w-4 mr-2" />
              OXXO Pay
            </Label>
          </div>
          
          <div className="flex items-center space-x-2 p-3 border rounded-lg">
            <RadioGroupItem value="transfer" id="transfer" />
            <Label htmlFor="transfer" className="flex items-center cursor-pointer">
              <Building className="h-4 w-4 mr-2" />
              Transferencia Bancaria
            </Label>
          </div>
        </RadioGroup>

        {formData.paymentMethod === 'credit_card' && (
          <div className="space-y-4 border-t pt-4">
            <div>
              <Label htmlFor="cardNumber">Número de Tarjeta *</Label>
              <Input
                id="cardNumber"
                value={formData.cardInfo.number}
                onChange={(e) => handleInputChange('cardInfo.number', e.target.value)}
                placeholder="1234 5678 9012 3456"
                maxLength={19}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="holderName">Nombre del Titular *</Label>
              <Input
                id="holderName"
                value={formData.cardInfo.holderName}
                onChange={(e) => handleInputChange('cardInfo.holderName', e.target.value)}
                placeholder="JUAN PEREZ"
                required
              />
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="expiryMonth">Mes *</Label>
                <Input
                  id="expiryMonth"
                  value={formData.cardInfo.expiryMonth}
                  onChange={(e) => handleInputChange('cardInfo.expiryMonth', e.target.value)}
                  placeholder="12"
                  maxLength={2}
                  required
                />
              </div>
              <div>
                <Label htmlFor="expiryYear">Año *</Label>
                <Input
                  id="expiryYear"
                  value={formData.cardInfo.expiryYear}
                  onChange={(e) => handleInputChange('cardInfo.expiryYear', e.target.value)}
                  placeholder="25"
                  maxLength={2}
                  required
                />
              </div>
              <div>
                <Label htmlFor="cvv">CVV *</Label>
                <Input
                  id="cvv"
                  value={formData.cardInfo.cvv}
                  onChange={(e) => handleInputChange('cardInfo.cvv', e.target.value)}
                  placeholder="123"
                  maxLength={4}
                  required
                />
              </div>
            </div>
          </div>
        )}

        {formData.paymentMethod === 'oxxo' && (
          <Alert>
            <AlertDescription>
              Después de confirmar tu pedido, recibirás un código de barras para pagar en cualquier tienda OXXO.
            </AlertDescription>
          </Alert>
        )}

        {formData.paymentMethod === 'transfer' && (
          <Alert>
            <AlertDescription>
              Te enviaremos los datos bancarios para realizar la transferencia. Tu pedido se procesará una vez confirmado el pago.
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );

  const renderStep4 = () => (
    <div className="text-center space-y-6">
      <CheckCircle className="h-16 w-16 text-green-500 mx-auto" />
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          ¡Pedido Confirmado!
        </h2>
        <p className="text-gray-600">
          Tu pedido #{orderId} ha sido procesado exitosamente
        </p>
      </div>
      
      <div className="bg-green-50 p-4 rounded-lg">
        <p className="text-green-800 text-sm">
          Recibirás un email de confirmación con los detalles de tu pedido y el tiempo estimado de entrega.
        </p>
      </div>

      <div className="space-y-3">
        <Button onClick={() => navigate('/pedidos')} className="w-full">
          Ver Mis Pedidos
        </Button>
        <Button variant="outline" onClick={() => navigate('/')} className="w-full">
          Continuar Comprando
        </Button>
      </div>
    </div>
  );

  if (orderPlaced) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-md mx-auto">
            {renderStep4()}
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Button variant="ghost" onClick={() => navigate('/carrito')} className="mr-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver al Carrito
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">
            Finalizar Compra
          </h1>
        </div>

        {/* Progress indicator */}
        <div className="flex items-center justify-center mb-8">
          {[1, 2, 3].map((stepNumber) => (
            <div key={stepNumber} className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= stepNumber 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-200 text-gray-600'
              }`}>
                {stepNumber}
              </div>
              {stepNumber < 3 && (
                <div className={`w-16 h-1 ${
                  step > stepNumber ? 'bg-blue-600' : 'bg-gray-200'
                }`} />
              )}
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main content */}
          <div className="lg:col-span-2">
            {step === 1 && renderStep1()}
            {step === 2 && renderStep2()}
            {step === 3 && renderStep3()}
            
            {/* Navigation buttons */}
            <div className="flex justify-between mt-6">
              {step > 1 && (
                <Button variant="outline" onClick={() => setStep(step - 1)}>
                  Anterior
                </Button>
              )}
              
              <div className="ml-auto">
                {step < 3 ? (
                  <Button 
                    onClick={handleNextStep}
                    disabled={!validateStep(step)}
                  >
                    Siguiente
                  </Button>
                ) : (
                  <Button 
                    onClick={handleSubmitOrder}
                    disabled={loading || !validateStep(step)}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {loading ? 'Procesando...' : 'Confirmar Pedido'}
                  </Button>
                )}
              </div>
            </div>
          </div>

          {/* Order summary */}
          <div>
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle>Resumen del Pedido</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Products */}
                <div className="space-y-3">
                  {cartProducts.map((item) => (
                    <div key={item.id} className="flex space-x-3">
                      <div className="w-12 h-12 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                        {item.images?.[0] ? (
                          <img 
                            src={item.images[0]} 
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Package className="h-4 w-4 text-gray-400" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1">
                        <h4 className="text-sm font-medium line-clamp-2">{item.name}</h4>
                        <div className="flex justify-between items-center mt-1">
                          <span className="text-sm text-gray-500">Qty: {item.cartQuantity}</span>
                          <span className="text-sm font-medium">
                            ${(item.price * item.cartQuantity).toLocaleString('es-MX')}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Subtotal</span>
                    <span>${subtotal.toLocaleString('es-MX')}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Envío</span>
                    <span>
                      {shipping === 0 ? (
                        <span className="text-green-600">Gratis</span>
                      ) : (
                        `$${shipping.toLocaleString('es-MX')}`
                      )}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>IVA</span>
                    <span>${tax.toLocaleString('es-MX')}</span>
                  </div>
                  <div className="flex justify-between font-semibold text-lg border-t pt-2">
                    <span>Total</span>
                    <span>${total.toLocaleString('es-MX')}</span>
                  </div>
                </div>

                {/* Security badges */}
                <div className="border-t pt-4">
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Shield className="h-4 w-4 text-green-500" />
                    <span>Compra 100% segura</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600 mt-2">
                    <Truck className="h-4 w-4 text-blue-500" />
                    <span>Envío asegurado</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default CheckoutPage;
