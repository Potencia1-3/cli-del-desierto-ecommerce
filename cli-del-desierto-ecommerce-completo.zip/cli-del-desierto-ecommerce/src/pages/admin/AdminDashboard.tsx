import React from 'react';
import Layout from '../../components/layout/Layout';
import { useApp } from '../../context/AppContext';

const AdminDashboard: React.FC = () => {
  const { state } = useApp();

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Panel de Administración</h1>
        <div className="bg-blue-50 p-4 rounded-lg mb-6">
          <p className="text-blue-800">
            Bienvenido, {state.auth.user?.firstName}. Panel de administración en desarrollo.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg border">
            <h3 className="text-lg font-semibold mb-2">Productos</h3>
            <p className="text-gray-600">Gestionar catálogo de productos</p>
          </div>
          <div className="bg-white p-6 rounded-lg border">
            <h3 className="text-lg font-semibold mb-2">Pedidos</h3>
            <p className="text-gray-600">Gestionar pedidos de clientes</p>
          </div>
          <div className="bg-white p-6 rounded-lg border">
            <h3 className="text-lg font-semibold mb-2">Cotizaciones</h3>
            <p className="text-gray-600">Responder cotizaciones</p>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default AdminDashboard;
