// Tipos principales del e-commerce Clí+ Del Desierto

export interface Company {
  name: string;
  tagline: string;
  description: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: Address;
  businessHours: BusinessHours;
  socialMedia: SocialMedia;
  logo: string;
  favicon: string;
}

export interface Address {
  street: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
}

export interface BusinessHours {
  monday: string;
  tuesday: string;
  wednesday: string;
  thursday: string;
  friday: string;
  saturday: string;
  sunday: string;
}

export interface SocialMedia {
  facebook: string;
  whatsapp: string;
  instagram: string;
}

export interface User {
  id: string;
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone: string;
  address: Address;
  role: 'customer' | 'admin';
  createdAt: string;
  isActive: boolean;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  parentId: string | null;
  image: string;
  isActive: boolean;
  subcategories?: Category[];
}

export interface Brand {
  id: string;
  name: string;
  description: string;
  logo: string;
  website: string;
  isActive: boolean;
  specialty?: string;
  colors?: {
    primary: string;
    secondary: string;
  };
}

export interface ProductSpecifications {
  [key: string]: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  shortDescription: string;
  sku: string;
  categoryId: string;
  brandId: string;
  price: number;
  comparePrice: number;
  cost: number;
  stock: number;
  minStock: number;
  images: string[];
  specifications: ProductSpecifications;
  tags: string[];
  isActive: boolean;
  isFeatured: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CartItem {
  productId: string;
  quantity: number;
  price: number;
}

export interface Cart {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  createdAt: string;
  updatedAt: string;
}

export interface QuoteItem {
  productId: string;
  quantity: number;
  requestedPrice: number;
  quotedPrice: number | null;
}

export interface Quote {
  id: string;
  userId: string;
  items: QuoteItem[];
  status: 'pending' | 'quoted' | 'accepted' | 'rejected';
  notes: string;
  adminNotes: string;
  total: number;
  quotedTotal?: number | null;
  createdAt: string;
  quotedAt: string | null;
  expiresAt: string | null;
}

export interface OrderItem {
  productId: string;
  quantity: number;
  price: number;
  total: number;
}

export interface Order {
  id: string;
  userId: string;
  orderNumber: string;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  shipping: number;
  total: number;
  status: 'pending' | 'paid' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  paymentMethod: string;
  paymentId: string;
  shippingAddress: Address;
  billingAddress: Address;
  createdAt: string;
  updatedAt: string;
}

export interface Payment {
  id: string;
  orderId: string;
  amount: number;
  method: 'credit_card' | 'paypal' | 'oxxo' | 'transfer';
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  transactionId: string;
  gateway: string;
  createdAt: string;
}

export interface SearchFilters {
  category?: string;
  brand?: string;
  minPrice?: number;
  maxPrice?: number;
  inStock?: boolean;
  featured?: boolean;
  query?: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
}

export interface CartState {
  items: CartItem[];
  total: number;
  itemCount: number;
}

export interface AppState {
  auth: AuthState;
  cart: CartState;
  wishlist: string[];
  currentUser: User | null;
}
